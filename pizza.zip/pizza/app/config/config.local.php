<?php
/** Configuração local pronta para XAMPP. Altera apenas se o teu MySQL tiver outra palavra-passe. */
define('DB_HOST', '127.0.0.1');
define('DB_NAME', 'pizzahub_v3');
define('DB_USER', 'root');
define('DB_PASS', '');

// Modo manual permite testar encomendas sem chave paga da Google Maps.
define('DISTANCE_MODE', 'manual');
define('GOOGLE_MAPS_API_KEY', '');
define('KITCHEN_ADDRESS', 'Maputo, Moçambique');
define('KITCHEN_LAT', '');
define('KITCHEN_LNG', '');

// Desenvolvimento local: mostra o erro técnico no navegador, útil para diagnóstico.
define('APP_ENV', 'development');
define('FORCE_HTTPS', false);
