<?php
declare(strict_types=1);

/**
 * Configuração base. Os valores reais (base de dados, chave Google) ficam em
 * app/config/config.local.php, que NÃO vai para o controlo de versões.
 * Copia config.local.example.php para config.local.php e ajusta.
 */
define('ROOT_PATH', dirname(__DIR__, 2));
define('STORAGE_PATH', ROOT_PATH . '/storage');
define('PUBLIC_PATH', ROOT_PATH);

$localConfig = __DIR__ . '/config.local.php';
if (is_file($localConfig)) {
    require $localConfig;
}

function config_default(string $name, mixed $value): void {
    if (!defined($name)) {
        define($name, $value);
    }
}

config_default('APP_NAME', 'PizzaHub');
config_default('APP_ENV', 'production');            // 'development' mostra erros no ecrã
config_default('DB_HOST', getenv('PIZZARIA_DB_HOST') ?: 'localhost');
config_default('DB_NAME', getenv('PIZZARIA_DB_NAME') ?: 'pizzaria');
config_default('DB_USER', getenv('PIZZARIA_DB_USER') ?: 'root');   // predefinição do XAMPP
config_default('DB_PASS', getenv('PIZZARIA_DB_PASS') ?: '');       // predefinição do XAMPP

// Google Maps Platform / Routes API (a chave fica apenas no servidor)
config_default('GOOGLE_MAPS_API_KEY', getenv('PIZZARIA_GOOGLE_KEY') ?: '');
config_default('KITCHEN_ADDRESS', 'Lichinga, Niassa, Moçambique');
config_default('KITCHEN_LAT', '');                  // opcional: latitude exacta da cozinha
config_default('KITCHEN_LNG', '');                  // opcional: longitude exacta da cozinha
config_default('DELIVERY_REGION_CODE', 'MZ');
// 'google' = distância calculada pela Routes API; 'manual' = o cliente escolhe a zona (modo sem mapa, identificado nas encomendas)
config_default('DISTANCE_MODE', 'google');
config_default('CURL_CA_BUNDLE', '');               // caminho do cacert.pem (XAMPP/Windows, se necessário)

config_default('FORCE_HTTPS', false);               // true quando o site estiver atrás de HTTPS
config_default('SESSION_IDLE_SECONDS', 7200);
config_default('MAX_UPLOAD_BYTES', 5 * 1024 * 1024);

if (!defined('BASE_URL')) {
    $scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/'));
    if (basename($scriptDir) === 'admin') {
        $scriptDir = dirname($scriptDir);
    }
    define('BASE_URL', ($scriptDir === '/' || $scriptDir === '.' || $scriptDir === '\\') ? '' : rtrim($scriptDir, '/'));
}

date_default_timezone_set('Africa/Maputo');
