<?php
declare(strict_types=1);

require_once __DIR__ . '/config.php';

// Protecao adicional: evita falha caso a configuracao local antiga nao defina APP_ENV.
if (!defined('APP_ENV')) {
    define('APP_ENV', 'production');
}
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/../helpers.php';
require_once __DIR__ . '/../services/Logger.php';
require_once __DIR__ . '/../services/UploadService.php';
require_once __DIR__ . '/../services/DistanceService.php';
require_once __DIR__ . '/../models/User.php';
require_once __DIR__ . '/../models/LoginAttempt.php';
require_once __DIR__ . '/../models/Promotion.php';
require_once __DIR__ . '/../models/Product.php';
require_once __DIR__ . '/../models/DeliveryRate.php';
require_once __DIR__ . '/../models/Cart.php';
require_once __DIR__ . '/../models/Order.php';
require_once __DIR__ . '/../models/Review.php';
require_once __DIR__ . '/../models/Stats.php';
require_once __DIR__ . '/../controllers/AuthController.php';
require_once __DIR__ . '/../controllers/CartController.php';
require_once __DIR__ . '/../controllers/OrderController.php';
require_once __DIR__ . '/../controllers/ReviewController.php';
require_once __DIR__ . '/../controllers/admin/ProductAdmin.php';
require_once __DIR__ . '/../controllers/admin/PromotionAdmin.php';
require_once __DIR__ . '/../controllers/admin/OrderAdmin.php';
require_once __DIR__ . '/../controllers/admin/DeliveryAdmin.php';

/* ---------- Erros: nunca mostrar detalhes internos ao utilizador final ---------- */
error_reporting(E_ALL);
ini_set('display_errors', APP_ENV === 'development' ? '1' : '0');
ini_set('log_errors', '1');
if (!is_dir(STORAGE_PATH . '/logs')) {
    @mkdir(STORAGE_PATH . '/logs', 0750, true);
}
ini_set('error_log', STORAGE_PATH . '/logs/php-error.log');

set_exception_handler(function (Throwable $error): void {
    app_log(get_class($error) . ': ' . $error->getMessage() . ' em ' . $error->getFile() . ':' . $error->getLine());
    if (!headers_sent()) {
        http_response_code(500);
    }
    $errorTitle = 'Ocorreu um erro';
    $errorMessage = APP_ENV === 'development'
        ? $error->getMessage()
        : 'Não foi possível concluir o pedido. Tenta novamente dentro de instantes. Se o problema continuar, contacta a pizzaria.';
    require __DIR__ . '/../views/pages/error.php';
});

/* ---------- HTTPS e cabeçalhos de segurança ---------- */
if (FORCE_HTTPS && !is_https() && PHP_SAPI !== 'cli') {
    header('Location: https://' . ($_SERVER['HTTP_HOST'] ?? '') . ($_SERVER['REQUEST_URI'] ?? '/'), true, 301);
    exit;
}
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Permissions-Policy: geolocation=(self), camera=(), microphone=()');
header("Content-Security-Policy: default-src 'self'; img-src 'self' data: blob: https:; style-src 'self' 'unsafe-inline'; script-src 'self' https://code.jquery.com; form-action 'self'; frame-ancestors 'self'; base-uri 'self'");
if (is_https() && FORCE_HTTPS) {
    header('Strict-Transport-Security: max-age=31536000');
}

/* ---------- Sessão ---------- */
session_name('PIZZARIA_SID');
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => is_https(),
    'httponly' => true,
    'samesite' => 'Lax',
]);
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
$now = time();
if (isset($_SESSION['last_activity']) && ($now - (int)$_SESSION['last_activity']) > SESSION_IDLE_SECONDS) {
    $_SESSION = [];
    session_regenerate_id(true);
}
$_SESSION['last_activity'] = $now;
