<?php
/**
 * Copia este ficheiro para config.local.php (na mesma pasta) e ajusta os valores.
 * config.local.php nunca deve ser partilhado nem enviado para o controlo de versões.
 */

// Base de dados (valores por omissão do XAMPP: utilizador root, sem palavra-passe)
define('DB_HOST', 'localhost');
define('DB_NAME', 'pizzahub_v3');
define('DB_USER', 'root');
define('DB_PASS', '');

// Google Maps Platform — Routes API (https://developers.google.com/maps/documentation/routes)
// Sem chave válida, o cálculo da distância (e por isso o fecho de encomendas) fica desativado.
define('GOOGLE_MAPS_API_KEY', '');

// Modo de entrega: 'google' (distância real pela Routes API) ou 'manual' (o cliente escolhe a zona
// de entrega; não há cálculo por mapa e a encomenda fica marcada como "zona informada").
define('DISTANCE_MODE', 'google');

// Ponto de referência da cozinha: usa coordenadas (mais precisas) OU o endereço.
define('KITCHEN_ADDRESS', 'Lichinga, Niassa, Moçambique');
define('KITCHEN_LAT', '');   // ex.: '-13.3128'
define('KITCHEN_LNG', '');   // ex.: '35.2406'

// Em produção deixa 'production'. Usa 'development' apenas no teu computador.
define('APP_ENV', 'production');

// Define true quando o site estiver disponível por HTTPS.
define('FORCE_HTTPS', false);

// Só necessário se o cURL do XAMPP/Windows falhar com "SSL certificate problem".
// define('CURL_CA_BUNDLE', 'C:/xampp/php/extras/ssl/cacert.pem');

// Só necessário se o site NÃO estiver em http://localhost/pizza
// define('BASE_URL', '/pizza');
