<?php
/** @var array $product produto com preço efetivo; @var string $returnPage página para onde voltar após adicionar */
$src = image_src($product['image_url'] ?? null);
$promo = $product['promotion'] ?? null;
$returnPage = $returnPage ?? 'menu.php';
?>
<article class="product-card" id="produto-<?= (int)$product['id'] ?>" data-category="<?= e($product['category'] ?? 'tradicionais') ?>">
  <div class="product-media">
    <?php if ($src): ?>
      <img src="<?= e($src) ?>" alt="<?= e($product['name']) ?>" loading="lazy">
    <?php else: ?>
      <div class="image-placeholder">Sem fotografia</div>
    <?php endif; ?>
    <?php if ($promo): ?><span class="tag-promo">Promoção</span><?php endif; ?>
  </div>
  <div class="product-body">
    <h3><?= e($product['name']) ?></h3>
    <?php if (!empty($product['review_count'])): ?>
      <p class="rating-line"><?= stars((float)$product['avg_rating']) ?> <span class="muted"><?= e(number_format((float)$product['avg_rating'], 1, ',', '')) ?> (<?= (int)$product['review_count'] ?>)</span></p>
    <?php endif; ?>
    <?php if (!empty($product['description'])): ?><p class="product-desc"><?= e($product['description']) ?></p><?php endif; ?>
    <?php if ($promo && !empty($promo['conditions'])): ?><p class="small-note">Condições: <?= e($promo['conditions']) ?></p><?php endif; ?>
    <div class="product-buy">
      <p class="price">
        <?php if ($promo): ?><del><?= money($product['list_price']) ?></del> <?php endif; ?>
        <strong><?= money($product['effective_price']) ?></strong>
      </p>
      <form method="post" action="<?= e(url('cart.php')) ?>" class="add-form">
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="add">
        <input type="hidden" name="product_id" value="<?= (int)$product['id'] ?>">
        <input type="hidden" name="return" value="<?= e($returnPage) ?>">
        <label class="qty-label">
          <span class="sr-only">Quantidade de <?= e($product['name']) ?></span>
          <input type="number" name="quantity" min="1" max="<?= CART_MAX_QTY ?>" value="1" inputmode="numeric">
        </label>
        <button type="submit">Adicionar</button>
      </form>
    </div>
  </div>
</article>
