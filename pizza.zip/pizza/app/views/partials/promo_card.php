<?php
/** @var array $promotion linha de promoção (com product_name/product_price quando associada a um produto) */
$src = image_src($promotion['image_url'] ?? null);
?>
<article class="promo-card">
  <?php if ($src): ?><img src="<?= e($src) ?>" alt="<?= e($promotion['title']) ?>" loading="lazy"><?php endif; ?>
  <div class="promo-body">
    <h3><?= e($promotion['title']) ?></h3>
    <?php if (!empty($promotion['description'])): ?><p><?= e($promotion['description']) ?></p><?php endif; ?>
    <?php if (!empty($promotion['product_id']) && $promotion['promo_price'] !== null): ?>
      <p class="promo-price"><?= e($promotion['product_name']) ?>:
        <del><?= money($promotion['product_price']) ?></del>
        <strong><?= money($promotion['promo_price']) ?></strong></p>
      <p><a class="button button-small" href="<?= e(url('menu.php#produto-' . (int)$promotion['product_id'])) ?>">Ver no cardápio</a></p>
    <?php endif; ?>
    <?php if (!empty($promotion['conditions'])): ?><p class="small-note">Condições: <?= e($promotion['conditions']) ?></p><?php endif; ?>
    <?php if (!empty($promotion['ends_at'])): ?><p class="small-note">Válida até <?= e(fmt_datetime($promotion['ends_at'])) ?></p><?php endif; ?>
  </div>
</article>
