<?php
$pageTitle = 'Encomenda #' . (int)$order['id'];
$navActive = 'orders';
$customerMap = maps_link($order['latitude'] ?? null, $order['longitude'] ?? null);
require __DIR__ . '/../layout/header.php';
/** @var array $order @var array $items @var ?array $review @var string[] $errors */
?>
<p><a href="<?= e(url('orders.php')) ?>">&larr; Minhas encomendas</a></p>
<div class="page-head">
  <h1>Encomenda #<?= (int)$order['id'] ?></h1>
  <?= status_badge((string)$order['status']) ?>
</div>

<div class="cart-layout">
  <div>
    <section class="panel">
      <h2>Produtos</h2>
      <div class="table-wrap">
        <table class="table-stack">
          <thead><tr><th>Produto</th><th>Preço</th><th>Quantidade</th><th>Total</th></tr></thead>
          <tbody>
          <?php foreach ($items as $item): ?>
            <tr>
              <td data-label="Produto"><?= e($item['product_name']) ?></td>
              <td data-label="Preço"><?= money($item['unit_price']) ?></td>
              <td data-label="Quantidade"><?= (int)$item['quantity'] ?></td>
              <td data-label="Total"><?= money($item['line_total']) ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </section>

    <section class="panel" id="avaliar">
      <h2>A tua avaliação</h2>
      <?php if ($review): ?>
        <p><?= stars((float)$review['rating']) ?> <span class="muted"><?= (int)$review['rating'] ?> de 5</span></p>
        <?php if (!empty($review['product_name'])): ?><p class="small-note">Pizza avaliada: <?= e($review['product_name']) ?></p><?php endif; ?>
        <?php if (!empty($review['comment'])): ?><blockquote class="review-comment"><?= nl2br(e($review['comment'])) ?></blockquote><?php endif; ?>
        <?php if (!empty($review['photo_id'])): ?>
          <img class="review-photo" src="<?= e(url('media.php?review=' . (int)$review['id'])) ?>" alt="Fotografia da pizza enviada por ti">
        <?php endif; ?>
        <p class="small-note">Avaliada em <?= e(fmt_datetime($review['created_at'])) ?>.</p>
      <?php elseif ($order['status'] === 'delivered'): ?>
        <?= errors_html($errors) ?>
        <form method="post" action="<?= e(url('order.php?id=' . (int)$order['id'])) ?>" enctype="multipart/form-data" class="review-form">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="review">
          <fieldset class="star-input">
            <legend>Classificação</legend>
            <div class="star-row">
              <?php for ($i = 5; $i >= 1; $i--): ?>
                <input type="radio" id="star<?= $i ?>" name="rating" value="<?= $i ?>" <?= field_value('rating') === (string)$i ? 'checked' : '' ?> required>
                <label for="star<?= $i ?>" title="<?= $i ?> <?= $i === 1 ? 'estrela' : 'estrelas' ?>"><span class="sr-only"><?= $i ?> <?= $i === 1 ? 'estrela' : 'estrelas' ?></span>★</label>
              <?php endfor; ?>
            </div>
          </fieldset>
          <?php if (count($items) > 1): ?>
            <label>Pizza que queres avaliar
              <select name="order_item_id" required>
                <option value="">Escolher&hellip;</option>
                <?php foreach ($items as $item): ?>
                  <option value="<?= (int)$item['id'] ?>" <?= field_value('order_item_id') === (string)$item['id'] ? 'selected' : '' ?>><?= e($item['product_name']) ?></option>
                <?php endforeach; ?>
              </select>
            </label>
          <?php endif; ?>
          <label>Comentário (opcional)
            <textarea name="comment" rows="4" maxlength="1000" placeholder="Como foi a pizza e a entrega?"><?= e(field_value('comment')) ?></textarea>
          </label>
          <label>Fotografia da pizza (opcional)
            <input type="file" name="photo" accept="image/jpeg,image/png,image/webp" data-preview="#photo-preview" data-max-bytes="<?= (int)MAX_UPLOAD_BYTES ?>">
          </label>
          <small class="small-note">JPG, PNG ou WEBP, até <?= e(upload_limit_label()) ?>.</small>
          <img id="photo-preview" class="review-photo" alt="Pré-visualização da fotografia" hidden>
          <button type="submit">Enviar avaliação</button>
        </form>
      <?php elseif ($order['status'] === 'cancelled'): ?>
        <p class="muted">Esta encomenda foi cancelada e não pode ser avaliada.</p>
      <?php else: ?>
        <p class="muted">Poderás avaliar a pizza depois de a encomenda ser entregue.</p>
      <?php endif; ?>
    </section>
  </div>

  <aside class="summary-card">
    <h2>Detalhes</h2>
    <dl class="detail-list">
      <div><dt>Data</dt><dd><?= e(fmt_datetime($order['created_at'])) ?></dd></div>
      <?php if (!empty($order['delivered_at'])): ?><div><dt>Entregue em</dt><dd><?= e(fmt_datetime($order['delivered_at'])) ?></dd></div><?php endif; ?>
      <div><dt>Morada</dt><dd><?= nl2br(e($order['address'])) ?></dd></div>
      <?php if ($customerMap): ?><div><dt>Localização marcada</dt><dd><a href="<?= e($customerMap) ?>" target="_blank" rel="noopener noreferrer">Ver alfinete no Google Maps</a></dd></div><?php endif; ?>
      <?php if (!empty($order['address_reference'])): ?><div><dt>Referência</dt><dd><?= e($order['address_reference']) ?></dd></div><?php endif; ?>
      <div><dt><?= ($order['distance_source'] ?? 'google') === 'manual' ? 'Zona de entrega' : 'Distância' ?></dt><dd><?= ($order['distance_source'] ?? 'google') === 'manual' ? 'Informada por ti (limite ' . e(fmt_km($order['distance_km'])) . ')' : e(fmt_km($order['distance_km'])) ?></dd></div>
      <div><dt>Pagamento</dt><dd><?= e(payment_method_label((string)$order['payment_method'])) ?></dd></div>
    </dl>
    <dl class="summary-list">
      <div><dt>Subtotal</dt><dd><?= money($order['subtotal']) ?></dd></div>
      <div><dt>Taxa de entrega</dt><dd><?= money($order['delivery_fee']) ?></dd></div>
      <div class="summary-total"><dt>Total</dt><dd><?= money($order['total']) ?></dd></div>
    </dl>
  </aside>
</div>
<?php require __DIR__ . '/../layout/footer.php'; ?>
