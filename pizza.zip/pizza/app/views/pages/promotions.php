<?php
$pageTitle = 'Promoções';
$navActive = 'promotions';
require __DIR__ . '/../layout/header.php';
?>
<h1>Promoções</h1>
<?php if (!$promotions): ?>
  <p class="empty">Não existem promoções ativas neste momento.</p>
<?php else: ?>
  <div class="grid grid-promos">
    <?php foreach ($promotions as $promotion): require __DIR__ . '/../partials/promo_card.php'; endforeach; ?>
  </div>
<?php endif; ?>
<?php require __DIR__ . '/../layout/footer.php'; ?>
