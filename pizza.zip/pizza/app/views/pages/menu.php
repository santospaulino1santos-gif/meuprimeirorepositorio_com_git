<?php
$pageTitle = 'Cardápio';
$navActive = 'menu';
require __DIR__ . '/../layout/header.php';
$usedCategories = array_unique(array_map(static fn(array $p): string => (string)($p['category'] ?? 'tradicionais'), $products));
?>
</div>
<section class="page-banner">
  <h1>Nosso Cardápio</h1>
  <p>Escolhe a tua pizza favorita! Preços em meticais (MT), pagamento em dinheiro na entrega.</p>
</section>
<div class="container">
<?php if (!$products): ?>
  <p class="empty">Ainda não há pizzas disponíveis no cardápio.</p>
<?php else: ?>
  <div class="filter-bar" role="group" aria-label="Categorias">
    <button type="button" class="filter-btn is-active" data-filter="all">Todas</button>
    <?php foreach (product_categories() as $key => $label): if (in_array($key, $usedCategories, true)): ?>
      <button type="button" class="filter-btn" data-filter="<?= e($key) ?>"><?= e($label) ?></button>
    <?php endif; endforeach; ?>
  </div>
  <div class="grid" id="product-grid">
    <?php $returnPage = 'menu.php'; foreach ($products as $product): require __DIR__ . '/../partials/product_card.php'; endforeach; ?>
  </div>
  <p class="empty" id="filter-empty" hidden>Não há pizzas nesta categoria.</p>
<?php endif; ?>
<?php require __DIR__ . '/../layout/footer.php'; ?>
