<?php
// Página de erro autónoma: não depende da base de dados nem da sessão.
$errorTitle = $errorTitle ?? 'Ocorreu um erro';
$errorMessage = $errorMessage ?? '';
?>
<!doctype html>
<html lang="pt">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex">
  <title><?= e($errorTitle) ?> | <?= e(APP_NAME) ?></title>
  <link rel="stylesheet" href="<?= e(asset('css/base.css')) ?>">
  <link rel="stylesheet" href="<?= e(asset('css/site.css')) ?>">
</head>
<body class="site-body">
<header class="site-header"><div class="header-inner"><a class="brand" href="<?= e(url('index.php')) ?>"><img src="<?= e(asset('img/logo.svg')) ?>" alt="" width="40" height="40"><span>Pizza<b>Hub</b></span></a></div></header>
<main><div class="container">
  <section class="error-page">
    <h1><?= e($errorTitle) ?></h1>
    <?php if ($errorMessage !== ''): ?><p><?= e($errorMessage) ?></p><?php endif; ?>
    <p><a class="button" href="<?= e(url('index.php')) ?>">Voltar ao início</a></p>
  </section>
</div></main>
</body>
</html>
