<?php
$pageTitle = 'Finalizar encomenda';
$navActive = 'cart';
require __DIR__ . '/../layout/header.php';
/** @var array $state  step, summary, form, quote, errors, configured */
$summary = $state['summary'];
$form = $state['form'];
$quote = $state['quote'];
?>
<h1>Finalizar encomenda</h1>
<?= errors_html($state['errors']) ?>
<?php if (distance_mode_manual()): ?>
  <div class="alert warning" role="status">Modo sem mapa: escolhe abaixo a zona de entrega onde ficas. A taxa corresponde à zona escolhida; a distância não é medida por mapa.</div>
<?php elseif (!$state['configured']): ?>
  <div class="alert warning" role="alert">O cálculo da distância ainda não está configurado (falta a chave da Google Maps Routes API). Não é possível finalizar encomendas até a pizzaria concluir esta configuração.</div>
<?php endif; ?>

<div class="cart-layout">
  <div>
  <?php if ($state['step'] === 'review' && $quote): ?>
    <section class="panel">
      <h2>Confirma a tua encomenda</h2>
      <dl class="detail-list">
        <div><dt>Recebe</dt><dd><?= e($form['name']) ?> &middot; <?= e($form['phone']) ?></dd></div>
        <div><dt>Morada</dt><dd><?= nl2br(e($form['address'])) ?></dd></div>
        <?php if ($form['reference'] !== ''): ?><div><dt>Ponto de referência</dt><dd><?= e($form['reference']) ?></dd></div><?php endif; ?>
        <?php if ($form['lat'] !== ''): ?><div><dt>Localização</dt><dd>Localização partilhada a partir do teu dispositivo</dd></div><?php endif; ?>
        <?php if ($form['notes'] !== ''): ?><div><dt>Observações</dt><dd><?= e($form['notes']) ?></dd></div><?php endif; ?>
        <?php if (($quote['source'] ?? 'google') === 'manual'): ?>
          <div><dt>Zona de entrega</dt><dd><?php foreach (delivery_rates_labeled() as $zr) { if ((int)$zr['id'] === (int)$quote['rate_id']) { echo e($zr['label']); } } ?> (informada por ti)</dd></div>
        <?php else: ?>
          <div><dt>Distância calculada</dt><dd><?= e(fmt_km($quote['distance_km'])) ?></dd></div>
        <?php endif; ?>
        <div><dt>Taxa de entrega</dt><dd><?= money($quote['fee']) ?></dd></div>
        <div><dt>Pagamento</dt><dd>Dinheiro no momento da entrega</dd></div>
      </dl>
      <p class="total-line">Total a pagar: <strong><?= money($quote['total']) ?></strong></p>
      <div class="form-actions">
        <form method="post" action="<?= e(url('checkout.php')) ?>" data-once>
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="confirm">
          <button type="submit">Confirmar encomenda</button>
        </form>
        <form method="post" action="<?= e(url('checkout.php')) ?>">
          <?= csrf_field() ?>
          <input type="hidden" name="action" value="edit">
          <button type="submit" class="button-outline">Alterar dados de entrega</button>
        </form>
      </div>
    </section>
  <?php else: ?>
    <section class="panel">
      <h2>Dados de entrega</h2>
      <form method="post" action="<?= e(url('checkout.php')) ?>" id="checkout-form" novalidate>
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="quote">
        <label>Nome de quem recebe
          <input name="name" maxlength="120" required autocomplete="name" value="<?= e($form['name']) ?>">
        </label>
        <label>Telefone para contacto
          <input name="phone" type="tel" maxlength="30" required autocomplete="tel" value="<?= e($form['phone']) ?>">
        </label>
        <label>Morada de entrega
          <textarea name="address" rows="3" maxlength="500" required placeholder="Bairro, rua, número da casa e cidade"><?= e($form['address']) ?></textarea>
        </label>
        <label>Ponto de referência (opcional)
          <input name="reference" maxlength="200" value="<?= e($form['reference']) ?>" placeholder="Ex.: junto à escola, portão azul">
        </label>
        <label>Observações para a entrega (opcional)
          <input name="notes" maxlength="300" value="<?= e($form['notes']) ?>">
        </label>
        <?php if (distance_mode_manual()): ?>
          <label>Zona de entrega
            <select name="zone" required>
              <option value="">Escolher a zona&hellip;</option>
              <?php foreach (delivery_rates_labeled() as $zr): ?>
                <option value="<?= (int)$zr['id'] ?>" <?= (string)$form['zone'] === (string)$zr['id'] ? 'selected' : '' ?>><?= e($zr['label']) ?> &mdash; <?= money($zr['fee']) ?></option>
              <?php endforeach; ?>
            </select>
          </label>
        <?php endif; ?>
        <div class="location-box">
          <input type="hidden" name="latitude" id="latitude" value="<?= e($form['lat']) ?>">
          <input type="hidden" name="longitude" id="longitude" value="<?= e($form['lng']) ?>">
          <button type="button" class="button-outline" id="use-location">Marcar a minha localização no mapa (GPS)</button>
          <button type="button" class="link-button" id="clear-location" <?= $form['lat'] === '' ? 'hidden' : '' ?>>Remover localização</button>
          <p class="small-note" id="location-status" aria-live="polite"><?= $form['lat'] !== '' ? 'Coordenadas GPS guardadas para esta entrega.' : 'Autoriza a localização no telemóvel. O GPS será guardado com a encomenda para o entregador abrir a rota.' ?></p>
          <a id="location-map-link" href="<?= $form['lat'] !== '' ? e(maps_link($form['lat'], $form['lng'])) : '#' ?>" target="_blank" rel="noopener noreferrer" <?= $form['lat'] === '' ? 'hidden' : '' ?>>Ver alfinete no Google Maps</a>
        </div>
        <button type="submit" <?= $state['configured'] ? '' : 'disabled' ?>>Calcular distância e taxa</button>
      </form>
    </section>
  <?php endif; ?>
  </div>

  <aside class="summary-card">
    <h2>A tua encomenda</h2>
    <ul class="mini-items">
      <?php foreach ($summary['items'] as $item): ?>
        <li><span><?= (int)$item['quantity'] ?> &times; <?= e($item['name']) ?></span><span><?= money($item['line_total']) ?></span></li>
      <?php endforeach; ?>
    </ul>
    <dl class="summary-list">
      <div><dt>Subtotal</dt><dd><?= money($summary['subtotal']) ?></dd></div>
      <div><dt>Taxa de entrega</dt><dd><?= $quote ? money($quote['fee']) : '<span class="muted">por calcular</span>' ?></dd></div>
      <div class="summary-total"><dt>Total</dt><dd><?= $quote ? money($quote['total']) : money($summary['subtotal']) ?></dd></div>
    </dl>
    <p class="small-note">Pagamento em dinheiro no momento da entrega.</p>
    <a href="<?= e(url('cart.php')) ?>">Voltar ao carrinho</a>
  </aside>
</div>
<?php require __DIR__ . '/../layout/footer.php'; ?>
