<?php
$pageTitle = 'Minhas encomendas';
$navActive = 'orders';
require __DIR__ . '/../layout/header.php';
?>
<h1>Minhas encomendas</h1>
<?php if (!$orders): ?>
  <p class="empty">Ainda não fizeste nenhuma encomenda. <a href="<?= e(url('menu.php')) ?>">Ver cardápio</a>.</p>
<?php else: ?>
  <div class="table-wrap">
    <table class="table-stack">
      <thead><tr><th>N.º</th><th>Data</th><th>Itens</th><th>Taxa de entrega</th><th>Total</th><th>Estado</th><th>Avaliação</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($orders as $order): ?>
        <tr>
          <td data-label="N.º">#<?= (int)$order['id'] ?></td>
          <td data-label="Data"><?= e(fmt_datetime($order['created_at'])) ?></td>
          <td data-label="Itens"><?= (int)$order['items_count'] ?></td>
          <td data-label="Taxa de entrega"><?= money($order['delivery_fee']) ?></td>
          <td data-label="Total"><strong><?= money($order['total']) ?></strong></td>
          <td data-label="Estado"><?= status_badge((string)$order['status']) ?></td>
          <td data-label="Avaliação">
            <?php if ($order['review_id'] !== null): ?>
              <?= stars((float)$order['review_rating']) ?>
            <?php elseif ($order['status'] === 'delivered'): ?>
              <a href="<?= e(url('order.php?id=' . (int)$order['id'] . '#avaliar')) ?>">Avaliar</a>
            <?php else: ?>
              <span class="muted">&mdash;</span>
            <?php endif; ?>
          </td>
          <td class="cell-actions"><a href="<?= e(url('order.php?id=' . (int)$order['id'])) ?>">Ver detalhes</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>
<?php require __DIR__ . '/../layout/footer.php'; ?>
