<?php
$pageTitle = 'Entrar';
$navActive = 'login';
require __DIR__ . '/../layout/header.php';
?>
<section class="form-card">
  <h1>Entrar</h1>
  <?= errors_html($errors) ?>
  <form method="post" action="<?= e(url('login.php')) ?>">
    <?= csrf_field() ?>
    <label>Email
      <input type="email" name="email" required autocomplete="email" maxlength="190" value="<?= e(field_value('email')) ?>">
    </label>
    <label>Palavra-passe
      <input type="password" name="password" required autocomplete="current-password">
    </label>
    <button type="submit">Entrar</button>
  </form>
  <p class="small-note">Ainda não tens conta? <a href="<?= e(url('register.php')) ?>">Criar conta</a></p>
</section>
<?php require __DIR__ . '/../layout/footer.php'; ?>
