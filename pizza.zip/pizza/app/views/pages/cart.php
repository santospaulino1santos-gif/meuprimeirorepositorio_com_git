<?php
$pageTitle = 'Carrinho';
$navActive = 'cart';
require __DIR__ . '/../layout/header.php';
?>
<h1>Carrinho</h1>
<?php if (!$cartItems): ?>
  <p class="empty">O carrinho está vazio. <a href="<?= e(url('menu.php')) ?>">Escolher pizzas no cardápio</a>.</p>
<?php else: ?>
<div class="cart-layout">
  <form method="post" action="<?= e(url('cart.php')) ?>" class="cart-form">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="update">
    <div class="table-wrap">
      <table class="table-stack">
        <thead><tr><th>Produto</th><th>Preço</th><th>Quantidade</th><th>Total</th><th><span class="sr-only">Remover</span></th></tr></thead>
        <tbody>
        <?php foreach ($cartItems as $item): $src = image_src($item['image_url']); ?>
          <tr>
            <td data-label="Produto">
              <div class="cell-product">
                <?php if ($src): ?><img src="<?= e($src) ?>" alt="" class="thumb"><?php endif; ?>
                <span><?= e($item['name']) ?><?php if ($item['promotion']): ?><br><span class="tag-inline">Promoção</span><?php endif; ?></span>
              </div>
            </td>
            <td data-label="Preço">
              <?php if ($item['promotion']): ?><del><?= money($item['list_price']) ?></del><br><?php endif; ?>
              <?= money($item['unit_price']) ?>
            </td>
            <td data-label="Quantidade">
              <div class="stepper">
                <button type="button" class="qty-btn" data-step="-1" aria-label="Diminuir quantidade">&minus;</button>
                <input type="number" name="qty[<?= (int)$item['id'] ?>]" value="<?= (int)$item['quantity'] ?>" min="0" max="<?= CART_MAX_QTY ?>" inputmode="numeric" aria-label="Quantidade de <?= e($item['name']) ?>">
                <button type="button" class="qty-btn" data-step="1" aria-label="Aumentar quantidade">+</button>
              </div>
            </td>
            <td data-label="Total"><strong><?= money($item['line_total']) ?></strong></td>
            <td class="cell-actions"><button type="submit" name="remove" value="<?= (int)$item['id'] ?>" class="button-link-danger">Remover</button></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class="form-actions">
      <button type="submit" class="button-outline">Atualizar quantidades</button>
      <a href="<?= e(url('menu.php')) ?>">Continuar a escolher</a>
    </div>
  </form>

  <aside class="summary-card">
    <h2>Resumo</h2>
    <dl class="summary-list">
      <div><dt>Subtotal</dt><dd><?= money($subtotal) ?></dd></div>
      <div><dt>Taxa de entrega</dt><dd class="muted">calculada pela distância</dd></div>
    </dl>
    <p class="small-note">A taxa de entrega é mostrada no passo seguinte, antes de confirmares. Pagamento em dinheiro no momento da entrega.</p>
    <a class="button button-block" href="<?= e(url('checkout.php')) ?>">Finalizar encomenda</a>
    <form method="post" action="<?= e(url('cart.php')) ?>" data-confirm="Esvaziar o carrinho?">
      <?= csrf_field() ?>
      <input type="hidden" name="action" value="clear">
      <button type="submit" class="link-button">Esvaziar carrinho</button>
    </form>
  </aside>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../layout/footer.php'; ?>
