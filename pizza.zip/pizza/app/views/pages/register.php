<?php
$pageTitle = 'Criar conta';
$navActive = 'login';
require __DIR__ . '/../layout/header.php';
?>
<section class="form-card">
  <h1>Criar conta</h1>
  <?= errors_html($errors) ?>
  <form method="post" action="<?= e(url('register.php')) ?>">
    <?= csrf_field() ?>
    <label>Nome completo
      <input name="name" required maxlength="120" autocomplete="name" value="<?= e(field_value('name')) ?>">
    </label>
    <label>Email
      <input type="email" name="email" required maxlength="190" autocomplete="email" value="<?= e(field_value('email')) ?>">
    </label>
    <label>Telefone (opcional)
      <input type="tel" name="phone" maxlength="30" autocomplete="tel" value="<?= e(field_value('phone')) ?>">
    </label>
    <label>Palavra-passe
      <input type="password" name="password" minlength="8" maxlength="72" required autocomplete="new-password">
    </label>
    <small class="small-note">Mínimo de 8 caracteres, com pelo menos uma letra e um número.</small>
    <label>Repetir palavra-passe
      <input type="password" name="password_confirm" minlength="8" maxlength="72" required autocomplete="new-password">
    </label>
    <button type="submit">Criar conta</button>
  </form>
  <p class="small-note">Já tens conta? <a href="<?= e(url('login.php')) ?>">Entrar</a></p>
</section>
<?php require __DIR__ . '/../layout/footer.php'; ?>
