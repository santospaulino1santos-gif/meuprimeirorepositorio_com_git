<?php
$pageTitle = 'Início';
$navActive = 'home';
require __DIR__ . '/../layout/header.php';
$heroImage = null;
foreach ($featured as $p) {
    if (!empty($p['image_url'])) { $heroImage = $p; break; }
}
?>
</div>
<section class="hero">
  <div class="hero-inner">
    <div class="hero-copy">
      <p class="hero-kicker">Bem-vindo ao</p>
      <h1>Pizza<span>Hub</span></h1>
      <p class="hero-slogan">Sabor que faz a diferença!</p>
      <p>Pizzas feitas na hora, entregues em tua casa. Escolhe no cardápio, indica onde estás e paga em dinheiro quando receberes.</p>
      <div class="hero-actions">
        <a class="button button-large" href="<?= e(url('menu.php')) ?>">Ver cardápio</a>
        <a class="button button-large button-dark" href="<?= e(url('promotions.php')) ?>">Promoções</a>
      </div>
    </div>
    <div class="hero-media">
      <?php if ($heroImage): ?>
        <img src="<?= e(image_src($heroImage['image_url'])) ?>" alt="<?= e($heroImage['name']) ?>">
      <?php else: ?>
        <div class="hero-empty">As fotografias das pizzas aparecem aqui assim que forem adicionadas no painel de administração.</div>
      <?php endif; ?>
    </div>
  </div>
</section>

<div class="container">
<section class="trust" aria-label="Vantagens">
  <div><strong>Pagamento na entrega</strong><span>Só pagas quando recebes</span></div>
  <div><strong>Entrega ao domicílio</strong><span>Taxa calculada pela distância</span></div>
  <div><strong>Acompanha o pedido</strong><span>Vê o estado em tempo real</span></div>
  <div><strong>Avaliações reais</strong><span>Classifica a pizza que recebeste</span></div>
</section>

<?php if ($promotions): ?>
<section class="section">
  <div class="section-title"><h2>Promoções em vigor</h2></div>
  <div class="grid grid-promos">
    <?php foreach ($promotions as $promotion): require __DIR__ . '/../partials/promo_card.php'; endforeach; ?>
  </div>
</section>
<?php endif; ?>

<section class="section">
  <div class="section-title"><h2>Nossas especialidades</h2></div>
  <?php if (!$featured): ?>
    <p class="empty">O cardápio ainda não tem pizzas disponíveis. Volta em breve.</p>
  <?php else: ?>
    <div class="grid">
      <?php $returnPage = 'index.php'; foreach ($featured as $product): require __DIR__ . '/../partials/product_card.php'; endforeach; ?>
    </div>
    <p class="center"><a class="button button-dark" href="<?= e(url('menu.php')) ?>">Ver cardápio completo</a></p>
  <?php endif; ?>
</section>

<section class="section delivery-info">
  <div class="section-title"><h2>Taxas de entrega</h2></div>
  <ul class="rate-list">
    <?php foreach ($rates as $rate): ?>
      <li><span><?= e($rate['label']) ?></span> <strong><?= money($rate['fee']) ?></strong></li>
    <?php endforeach; ?>
  </ul>
  <p class="center muted">Trabalhamos apenas com encomendas online. A taxa é calculada pela distância de condução até à tua morada e é mostrada antes de confirmares.</p>
</section>
<?php require __DIR__ . '/../layout/footer.php'; ?>
