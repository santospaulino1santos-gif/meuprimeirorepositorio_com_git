    </main>
    <footer class="admin-footer"><span><b>Pizza<i>Hub</i></b> &copy; <?= date('Y') ?>. Painel de administração.</span><a href="<?= e(url('index.php')) ?>">Ver site</a></footer>
  </div>
</div>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" crossorigin="anonymous"></script>
<script src="<?= e(asset('js/admin.js')) ?>"></script>
</body>
</html>
