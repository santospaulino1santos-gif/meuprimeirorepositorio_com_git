</div>
</main>
<footer class="site-footer">
  <div class="footer-inner">
    <div><strong>Pizza<b>Hub</b></strong><p>Pizzaria com encomendas exclusivamente online e entrega ao domicílio.</p></div>
    <div><strong>Pagamento</strong><p>Dinheiro no momento da entrega.</p></div>
    <div><strong>A tua conta</strong>
      <p><?php if (current_user()): ?><a href="<?= e(url('orders.php')) ?>">Minhas encomendas</a><?php else: ?><a href="<?= e(url('login.php')) ?>">Entrar</a> &nbsp; <a href="<?= e(url('register.php')) ?>">Criar conta</a><?php endif; ?></p></div>
  </div>
  <p class="copyright">&copy; <?= date('Y') ?> <?= e(APP_NAME) ?>. Todos os direitos reservados.</p>
</footer>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" crossorigin="anonymous"></script>
<script src="<?= e(asset('js/site.js')) ?>"></script>
</body>
</html>
