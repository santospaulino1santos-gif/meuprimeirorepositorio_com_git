<?php
$flashMessage = take_flash();
$pageTitle = $pageTitle ?? APP_NAME;
$navActive = $navActive ?? '';
$authUser = current_user();
$cartCount = cart_count();
?>
<!doctype html>
<html lang="pt">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($pageTitle) ?> | <?= e(APP_NAME) ?></title>
  <link rel="icon" href="<?= e(asset('img/logo.svg')) ?>" type="image/svg+xml">
  <link rel="stylesheet" href="<?= e(asset('css/base.css')) ?>">
  <link rel="stylesheet" href="<?= e(asset('css/site.css')) ?>">
</head>
<body class="site-body">
<a class="skip-link" href="#conteudo">Saltar para o conteúdo</a>
<header class="site-header">
  <div class="header-inner">
    <a class="brand" href="<?= e(url('index.php')) ?>"><img src="<?= e(asset('img/logo.svg')) ?>" alt="" width="40" height="40"><span>Pizza<b>Hub</b></span></a>
    <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="main-nav">Menu</button>
    <nav id="main-nav" class="main-nav" aria-label="Principal">
      <a href="<?= e(url('index.php')) ?>" class="<?= $navActive === 'home' ? 'is-active' : '' ?>">Início</a>
      <a href="<?= e(url('menu.php')) ?>" class="<?= $navActive === 'menu' ? 'is-active' : '' ?>">Cardápio</a>
      <a href="<?= e(url('promotions.php')) ?>" class="<?= $navActive === 'promotions' ? 'is-active' : '' ?>">Promoções</a>
      <?php if ($authUser): ?><a href="<?= e(url('orders.php')) ?>" class="<?= $navActive === 'orders' ? 'is-active' : '' ?>">Minhas encomendas</a><?php endif; ?>
    </nav>
    <div class="header-actions">
      <a class="cart-link" href="<?= e(url('cart.php')) ?>" aria-label="Carrinho, <?= (int)$cartCount ?> itens">
        <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.6 11.4a1 1 0 0 0 1 .8h9.2a1 1 0 0 0 1-.8L21 7H6"/></svg>
        <span class="cart-count" id="cart-count"><?= (int)$cartCount ?></span>
      </a>
      <?php if ($authUser): ?>
        <?php if ($authUser['role'] === 'admin'): ?><a class="button button-small button-dark" href="<?= e(url('admin/dashboard.php')) ?>">Administração</a><?php endif; ?>
        <form method="post" action="<?= e(url('logout.php')) ?>" class="nav-form"><?= csrf_field() ?><button type="submit" class="button button-small button-outline">Sair</button></form>
      <?php else: ?>
        <a class="button button-small" href="<?= e(url('login.php')) ?>">Entrar</a>
      <?php endif; ?>
    </div>
  </div>
</header>
<main id="conteudo">
<div class="container">
<?php if ($flashMessage): ?><div class="alert <?= e($flashMessage['type']) ?>" role="status"><?= e($flashMessage['message']) ?></div><?php endif; ?>
