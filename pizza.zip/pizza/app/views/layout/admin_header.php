<?php
$flashMessage = take_flash();
$pageTitle = $pageTitle ?? 'Administração';
$adminActive = $adminActive ?? '';
$authUser = current_user();
$adminLinks = [
    'dashboard' => ['admin/dashboard.php', 'Dashboard'],
    'products' => ['admin/products.php', 'Produtos'],
    'promotions' => ['admin/promotions.php', 'Promoções'],
    'orders' => ['admin/orders.php', 'Pedidos'],
    'customers' => ['admin/customers.php', 'Clientes'],
    'reviews' => ['admin/reviews.php', 'Avaliações'],
    'delivery' => ['admin/delivery.php', 'Taxas de entrega'],
];
?>
<!doctype html>
<html lang="pt">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex, nofollow">
  <title><?= e($pageTitle) ?> | Administração | <?= e(APP_NAME) ?></title>
  <link rel="icon" href="<?= e(asset('img/logo.svg')) ?>" type="image/svg+xml">
  <link rel="stylesheet" href="<?= e(asset('css/base.css')) ?>">
  <link rel="stylesheet" href="<?= e(asset('css/admin.css')) ?>">
</head>
<body class="admin-body">
<a class="skip-link" href="#conteudo">Saltar para o conteúdo</a>
<div class="admin-shell">
  <aside class="sidebar" id="sidebar" aria-label="Administração">
    <a class="sidebar-brand" href="<?= e(url('admin/dashboard.php')) ?>"><img src="<?= e(asset('img/logo.svg')) ?>" alt="" width="36" height="36"><span>Pizza<b>Hub</b></span></a>
    <nav>
      <?php foreach ($adminLinks as $key => [$path, $label]): ?>
        <a href="<?= e(url($path)) ?>" class="<?= $adminActive === $key ? 'is-active' : '' ?>"><?= e($label) ?></a>
      <?php endforeach; ?>
      <a href="<?= e(url('index.php')) ?>">Ver site</a>
      <form method="post" action="<?= e(url('logout.php')) ?>"><?= csrf_field() ?><button type="submit">Sair</button></form>
    </nav>
  </aside>
  <div class="admin-main">
    <header class="admin-topbar">
      <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="sidebar">Menu</button>
      <span class="admin-user">Olá, <?= e($authUser['name'] ?? '') ?></span>
    </header>
    <main id="conteudo" class="admin-content">
<?php if ($flashMessage): ?><div class="alert <?= e($flashMessage['type']) ?>" role="status"><?= e($flashMessage['message']) ?></div><?php endif; ?>
