<?php
$pageTitle = 'Taxas de entrega'; $adminActive = 'delivery';
require __DIR__ . '/../layout/admin_header.php';
$last = count($rates) - 1;
?>
<h1>Taxas de entrega</h1>
<p class="lead">A taxa é escolhida pela distância de condução entre a cozinha e o cliente. Alterações aplicam-se às encomendas seguintes; as anteriores mantêm o valor que foi cobrado.</p>
<?= errors_html($errors) ?>
<form method="post" action="<?= e(url('admin/delivery.php')) ?>" class="panel">
  <?= csrf_field() ?>
  <div class="table-wrap"><table class="table-stack">
    <thead><tr><th>Faixa</th><th>Limite superior (km)</th><th>Taxa (MT)</th></tr></thead>
    <tbody>
    <?php foreach ($rates as $i => $r): $id = (int)$r['id']; ?>
      <tr>
        <td data-label="Faixa"><?= e($r['label']) ?></td>
        <td data-label="Limite superior (km)">
          <?php if ($i < $last): ?>
            <input name="max_km[<?= $id ?>]" inputmode="decimal" required value="<?= e(is_post() ? (string)($_POST['max_km'][$id] ?? '') : rtrim(rtrim(number_format((float)$r['max_km'], 2, ',', ''), '0'), ',')) ?>">
          <?php else: ?><span class="muted">sem limite</span><?php endif; ?>
        </td>
        <td data-label="Taxa (MT)"><input name="fee[<?= $id ?>]" inputmode="decimal" required value="<?= e(is_post() ? (string)($_POST['fee'][$id] ?? '') : number_format((float)$r['fee'], 2, ',', '')) ?>"></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
  <button type="submit">Guardar taxas</button>
</form>
<?php require __DIR__ . '/../layout/admin_footer.php'; ?>
