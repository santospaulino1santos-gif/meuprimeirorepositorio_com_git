<?php
$pageTitle = 'Clientes'; $adminActive = 'customers';
require __DIR__ . '/../layout/admin_header.php';
?>
<h1>Clientes</h1>
<form method="get" action="<?= e(url('admin/customers.php')) ?>" class="filters">
  <label>Pesquisar<input type="search" name="q" value="<?= e($search) ?>" placeholder="Nome, email ou telefone"></label>
  <button type="submit">Pesquisar</button>
</form>
<?php if (!$customers): ?><p class="empty">Nenhum cliente encontrado.</p><?php else: ?>
<div class="table-wrap"><table class="table-stack">
  <thead><tr><th>Nome</th><th>Email</th><th>Telefone</th><th>Registo</th><th>Encomendas</th><th>Total gasto</th><th></th></tr></thead>
  <tbody><?php foreach ($customers as $c): ?>
    <tr>
      <td data-label="Nome"><?= e($c['name']) ?></td>
      <td data-label="Email"><?= e($c['email']) ?></td>
      <td data-label="Telefone"><?= e($c['phone'] ?? '—') ?></td>
      <td data-label="Registo"><?= e(fmt_date($c['created_at'])) ?></td>
      <td data-label="Encomendas"><?= (int)$c['orders_count'] ?></td>
      <td data-label="Total gasto"><?= money($c['total_spent']) ?></td>
      <td class="cell-actions"><a href="<?= e(url('admin/customers.php?id=' . (int)$c['id'])) ?>">Ver histórico</a></td>
    </tr>
  <?php endforeach; ?></tbody>
</table></div>
<?= pagination_html($total, $perPage, $page, ['q' => $search]) ?>
<?php endif; ?>
<?php require __DIR__ . '/../layout/admin_footer.php'; ?>
