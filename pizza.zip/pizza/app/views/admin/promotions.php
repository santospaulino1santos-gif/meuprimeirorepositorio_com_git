<?php
$pageTitle = 'Promoções'; $adminActive = 'promotions';
require __DIR__ . '/../layout/admin_header.php';
$form = $editing ?? [];
$showForm = $editing || $result['action'] === 'create' || get_int('new') === 1;
$activeDefault = $editing ? (int)$editing['active'] : 1;
$activeChecked = is_post() ? isset($_POST['active']) : (bool)$activeDefault;
?>
<h1>Promoções</h1>
<?= errors_html($result['errors']) ?>
<?php if ($showForm): ?>
<section class="panel">
  <h2><?= $editing ? 'Editar promoção' : 'Criar promoção' ?></h2>
  <form method="post" action="<?= e(url('admin/promotions.php' . ($editing ? '?edit=' . (int)$editing['id'] : ''))) ?>" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="<?= $editing ? 'update' : 'create' ?>">
    <?php if ($editing): ?><input type="hidden" name="promotion_id" value="<?= (int)$editing['id'] ?>"><?php endif; ?>
    <label>Título<input name="title" maxlength="150" required value="<?= e(field_value('title', $form)) ?>"></label>
    <label>Descrição<textarea name="description" rows="3" maxlength="1000"><?= e(field_value('description', $form)) ?></textarea></label>
    <label>Condições (opcional)<input name="conditions" maxlength="500" value="<?= e(field_value('conditions', $form)) ?>"></label>
    <label>Produto em promoção (opcional)
      <select name="product_id">
        <option value="">Nenhum (promoção informativa)</option>
        <?php foreach ($selectableProducts as $p): ?>
          <option value="<?= (int)$p['id'] ?>" <?= field_value('product_id', $form) === (string)$p['id'] ? 'selected' : '' ?>><?= e($p['name']) ?> (<?= money($p['price']) ?>)</option>
        <?php endforeach; ?>
      </select>
    </label>
    <label>Preço promocional (MT) &mdash; obrigatório se escolheres um produto
      <input name="promo_price" inputmode="decimal" value="<?= e(field_value('promo_price', $form)) ?>">
    </label>
    <div class="two-col">
      <label>Início (opcional)<input type="datetime-local" name="starts_at" value="<?= e(is_post() ? post_string('starts_at') : datetime_local_value($form['starts_at'] ?? null)) ?>"></label>
      <label>Fim (opcional)<input type="datetime-local" name="ends_at" value="<?= e(is_post() ? post_string('ends_at') : datetime_local_value($form['ends_at'] ?? null)) ?>"></label>
    </div>
    <?php if ($editing && ($src = image_src($editing['image_url']))): ?><img class="thumb-large" src="<?= e($src) ?>" alt="Imagem atual"><?php endif; ?>
    <label><?= $editing ? 'Substituir imagem' : 'Imagem' ?><input type="file" name="image" accept="image/jpeg,image/png,image/webp" data-preview="#img-preview" data-max-bytes="<?= (int)MAX_UPLOAD_BYTES ?>"></label>
    <img id="img-preview" class="thumb-large" alt="Pré-visualização" hidden>
    <label class="check"><input type="checkbox" name="active" value="1" <?= $activeChecked ? 'checked' : '' ?>> Promoção ativa</label>
    <div class="form-actions"><button type="submit">Guardar</button><a href="<?= e(url('admin/promotions.php')) ?>">Cancelar</a></div>
  </form>
</section>
<?php else: ?>
  <p><a class="button" href="<?= e(url('admin/promotions.php?new=1')) ?>">Criar promoção</a></p>
<?php endif; ?>

<?php if (!$promotions): ?><p class="empty">Ainda não há promoções criadas.</p><?php else: ?>
<div class="table-wrap">
  <table class="table-stack">
    <thead><tr><th>Promoção</th><th>Produto e preço</th><th>Validade</th><th>Estado</th><th>Ações</th></tr></thead>
    <tbody>
    <?php foreach ($promotions as $pr): [$stateLabel, $stateClass] = promotion_state($pr); ?>
      <tr>
        <td data-label="Promoção"><strong><?= e($pr['title']) ?></strong><?php if (!empty($pr['conditions'])): ?><br><span class="small-note"><?= e($pr['conditions']) ?></span><?php endif; ?></td>
        <td data-label="Produto e preço"><?= $pr['product_name'] ? e($pr['product_name']) . '<br>' . money($pr['promo_price']) . ' <del class="muted">' . money($pr['product_price']) . '</del>' : '<span class="muted">Informativa</span>' ?></td>
        <td data-label="Validade"><?= e(fmt_datetime($pr['starts_at'])) ?> a <?= e(fmt_datetime($pr['ends_at'])) ?></td>
        <td data-label="Estado"><span class="badge badge-<?= e($stateClass) ?>"><?= e($stateLabel) ?></span></td>
        <td class="cell-actions action-group">
          <a href="<?= e(url('admin/promotions.php?edit=' . (int)$pr['id'])) ?>">Editar</a>
          <form method="post" action="<?= e(url('admin/promotions.php')) ?>"><?= csrf_field() ?><input type="hidden" name="action" value="<?= (int)$pr['active'] ? 'deactivate' : 'activate' ?>"><input type="hidden" name="promotion_id" value="<?= (int)$pr['id'] ?>"><button type="submit" class="link-button"><?= (int)$pr['active'] ? 'Desativar' : 'Ativar' ?></button></form>
          <form method="post" action="<?= e(url('admin/promotions.php')) ?>" data-confirm="Remover esta promoção definitivamente?"><?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="promotion_id" value="<?= (int)$pr['id'] ?>"><button type="submit" class="button-link-danger">Remover</button></form>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../layout/admin_footer.php'; ?>
