<?php
$pageTitle = 'Encomendas'; $adminActive = 'orders';
require __DIR__ . '/../layout/admin_header.php';
?>
<h1>Encomendas</h1>
<form method="get" action="<?= e(url('admin/orders.php')) ?>" class="filters">
  <label>Estado
    <select name="status" data-autosubmit>
      <option value="">Todos (<?= (int)array_sum($counts) ?>)</option>
      <?php foreach (order_statuses() as $key => $label): ?>
        <option value="<?= e($key) ?>" <?= $status === $key ? 'selected' : '' ?>><?= e($label) ?> (<?= (int)$counts[$key] ?>)</option>
      <?php endforeach; ?>
    </select>
  </label>
  <label>Pesquisar<input type="search" name="q" value="<?= e($search) ?>" placeholder="N.º, nome, email ou telefone"></label>
  <button type="submit">Filtrar</button>
</form>
<?php if (!$orders): ?><p class="empty">Nenhuma encomenda encontrada.</p><?php else: ?>
<div class="table-wrap">
  <table class="table-stack">
    <thead><tr><th>N.º</th><th>Data</th><th>Cliente</th><th>Distância</th><th>Total</th><th>Estado</th><th>Atualizar estado</th></tr></thead>
    <tbody>
    <?php foreach ($orders as $o): $next = allowed_next_statuses((string)$o['status']); ?>
      <tr>
        <td data-label="N.º"><a href="<?= e(url('admin/orders.php?id=' . (int)$o['id'])) ?>">#<?= (int)$o['id'] ?></a></td>
        <td data-label="Data"><?= e(fmt_datetime($o['created_at'])) ?></td>
        <td data-label="Cliente"><?= e($o['display_name']) ?><br><span class="small-note"><?= e($o['phone'] ?? $o['account_email']) ?></span></td>
        <td data-label="Distância"><?= e(fmt_km($o['distance_km'])) ?></td>
        <td data-label="Total"><?= money($o['total']) ?></td>
        <td data-label="Estado"><?= status_badge((string)$o['status']) ?></td>
        <td class="cell-actions">
          <?php if ($next): ?>
            <form method="post" action="<?= e(url('admin/orders.php')) ?>" class="inline-form"><?= csrf_field() ?>
              <input type="hidden" name="action" value="status"><input type="hidden" name="order_id" value="<?= (int)$o['id'] ?>"><input type="hidden" name="return" value="list">
              <select name="status" aria-label="Novo estado da encomenda <?= (int)$o['id'] ?>"><?php foreach ($next as $st): ?><option value="<?= e($st) ?>"><?= e(status_label($st)) ?></option><?php endforeach; ?></select>
              <button type="submit">Atualizar</button>
            </form>
          <?php else: ?><span class="muted">Estado final</span><?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?= pagination_html($total, $perPage, $page, ['status' => $status, 'q' => $search]) ?>
<?php endif; ?>
<?php require __DIR__ . '/../layout/admin_footer.php'; ?>
