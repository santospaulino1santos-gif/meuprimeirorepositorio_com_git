<?php
$pageTitle = 'Encomenda #' . (int)$order['id']; $adminActive = 'orders';
require __DIR__ . '/../layout/admin_header.php';
$next = allowed_next_statuses((string)$order['status']);
$map = maps_link($order['latitude'] ?? null, $order['longitude'] ?? null);
$routeMap = maps_directions_link($order['latitude'] ?? null, $order['longitude'] ?? null);
?>
<p><a href="<?= e(url('admin/orders.php')) ?>">&larr; Encomendas</a></p>
<div class="page-head"><h1>Encomenda #<?= (int)$order['id'] ?></h1><?= status_badge((string)$order['status']) ?></div>
<div class="two-col">
  <section class="panel">
    <h2>Entrega</h2>
    <dl class="detail-list">
      <div><dt>Nome</dt><dd><?= e($order['customer_name'] ?? $order['account_name']) ?></dd></div>
      <div><dt>Telefone</dt><dd><?= e($order['phone'] ?? '—') ?></dd></div>
      <div><dt>Conta</dt><dd><?= e($order['account_name']) ?> (<?= e($order['account_email']) ?>)</dd></div>
      <div><dt>Morada</dt><dd><?= nl2br(e($order['address'])) ?></dd></div>
      <?php if (!empty($order['address_reference'])): ?><div><dt>Referência</dt><dd><?= e($order['address_reference']) ?></dd></div><?php endif; ?>
      <?php if (!empty($order['notes'])): ?><div><dt>Observações</dt><dd><?= e($order['notes']) ?></dd></div><?php endif; ?>
      <?php if ($map): ?><div><dt>Alfinete da entrega</dt><dd><a href="<?= e($map) ?>" target="_blank" rel="noopener noreferrer">Ver localização no Google Maps</a> · <a href="<?= e($routeMap) ?>" target="_blank" rel="noopener noreferrer">Traçar rota para entrega</a></dd></div><?php else: ?><div><dt>Localização</dt><dd>O cliente não partilhou coordenadas GPS. Usa a morada e o ponto de referência.</dd></div><?php endif; ?>
      <div><dt><?= ($order['distance_source'] ?? 'google') === 'manual' ? 'Zona de entrega' : 'Distância' ?></dt><dd><?= ($order['distance_source'] ?? 'google') === 'manual' ? 'Informada pelo cliente, sem cálculo por mapa (limite ' . e(fmt_km($order['distance_km'])) . ')' : e(fmt_km($order['distance_km'])) ?></dd></div>
      <div><dt>Pagamento</dt><dd><?= e(payment_method_label((string)$order['payment_method'])) ?></dd></div>
      <div><dt>Criada em</dt><dd><?= e(fmt_datetime($order['created_at'])) ?></dd></div>
      <?php if (!empty($order['delivered_at'])): ?><div><dt>Entregue em</dt><dd><?= e(fmt_datetime($order['delivered_at'])) ?></dd></div><?php endif; ?>
    </dl>
  </section>
  <section class="panel">
    <h2>Estado</h2>
    <?php if ($next): ?>
      <form method="post" action="<?= e(url('admin/orders.php')) ?>"><?= csrf_field() ?>
        <input type="hidden" name="action" value="status"><input type="hidden" name="order_id" value="<?= (int)$order['id'] ?>">
        <label>Novo estado<select name="status"><?php foreach ($next as $st): ?><option value="<?= e($st) ?>"><?= e(status_label($st)) ?></option><?php endforeach; ?></select></label>
        <button type="submit">Atualizar estado</button>
      </form>
    <?php else: ?><p class="muted">Esta encomenda está num estado final.</p><?php endif; ?>
    <h2>Valores</h2>
    <dl class="summary-list">
      <div><dt>Subtotal</dt><dd><?= money($order['subtotal']) ?></dd></div>
      <div><dt>Taxa de entrega</dt><dd><?= money($order['delivery_fee']) ?></dd></div>
      <div class="summary-total"><dt>Total</dt><dd><?= money($order['total']) ?></dd></div>
    </dl>
  </section>
</div>
<section class="panel">
  <h2>Produtos</h2>
  <div class="table-wrap"><table class="table-stack">
    <thead><tr><th>Produto</th><th>Preço</th><th>Quantidade</th><th>Total</th></tr></thead>
    <tbody><?php foreach ($items as $it): ?>
      <tr><td data-label="Produto"><?= e($it['product_name']) ?></td><td data-label="Preço"><?= money($it['unit_price']) ?><?php if ($it['list_price'] !== null && (float)$it['list_price'] > (float)$it['unit_price']): ?> <del class="muted"><?= money($it['list_price']) ?></del><?php endif; ?></td><td data-label="Quantidade"><?= (int)$it['quantity'] ?></td><td data-label="Total"><?= money($it['line_total']) ?></td></tr>
    <?php endforeach; ?></tbody>
  </table></div>
</section>
<?php if ($review): ?>
<section class="panel">
  <h2>Avaliação do cliente</h2>
  <p><?= stars((float)$review['rating']) ?> <?= (int)$review['rating'] ?> de 5<?php if (!empty($review['product_name'])): ?> &mdash; <?= e($review['product_name']) ?><?php endif; ?></p>
  <?php if (!empty($review['comment'])): ?><blockquote class="review-comment"><?= nl2br(e($review['comment'])) ?></blockquote><?php endif; ?>
  <?php if (!empty($review['photo_id'])): ?><img class="review-photo" src="<?= e(url('media.php?review=' . (int)$review['id'])) ?>" alt="Fotografia enviada pelo cliente"><?php endif; ?>
  <p class="small-note"><?= e(fmt_datetime($review['created_at'])) ?></p>
</section>
<?php endif; ?>
<?php require __DIR__ . '/../layout/admin_footer.php'; ?>
