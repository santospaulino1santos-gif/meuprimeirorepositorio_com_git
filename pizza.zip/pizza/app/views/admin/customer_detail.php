<?php
$pageTitle = $customer['name']; $adminActive = 'customers';
require __DIR__ . '/../layout/admin_header.php';
?>
<p><a href="<?= e(url('admin/customers.php')) ?>">&larr; Clientes</a></p>
<h1><?= e($customer['name']) ?></h1>
<section class="panel">
  <dl class="detail-list">
    <div><dt>Email</dt><dd><?= e($customer['email']) ?></dd></div>
    <div><dt>Telefone</dt><dd><?= e($customer['phone'] ?? '—') ?></dd></div>
    <div><dt>Registado em</dt><dd><?= e(fmt_date($customer['created_at'])) ?></dd></div>
    <div><dt>Encomendas</dt><dd><?= (int)$customer['orders_count'] ?></dd></div>
    <div><dt>Total gasto (sem canceladas)</dt><dd><?= money($customer['total_spent']) ?></dd></div>
    <div><dt>Avaliações enviadas</dt><dd><?= (int)$customer['reviews_count'] ?></dd></div>
  </dl>
</section>
<h2>Histórico de encomendas</h2>
<?php if (!$orders): ?><p class="empty">Este cliente ainda não fez encomendas.</p><?php else: ?>
<div class="table-wrap"><table class="table-stack">
  <thead><tr><th>N.º</th><th>Data</th><th>Total</th><th>Estado</th><th>Avaliação</th><th></th></tr></thead>
  <tbody><?php foreach ($orders as $o): ?>
    <tr>
      <td data-label="N.º">#<?= (int)$o['id'] ?></td>
      <td data-label="Data"><?= e(fmt_datetime($o['created_at'])) ?></td>
      <td data-label="Total"><?= money($o['total']) ?></td>
      <td data-label="Estado"><?= status_badge((string)$o['status']) ?></td>
      <td data-label="Avaliação"><?= $o['review_id'] !== null ? stars((float)$o['review_rating']) : '<span class="muted">&mdash;</span>' ?></td>
      <td class="cell-actions"><a href="<?= e(url('admin/orders.php?id=' . (int)$o['id'])) ?>">Ver encomenda</a></td>
    </tr>
  <?php endforeach; ?></tbody>
</table></div>
<?php endif; ?>
<?php require __DIR__ . '/../layout/admin_footer.php'; ?>
