<?php
$pageTitle = 'Produtos'; $adminActive = 'products';
require __DIR__ . '/../layout/admin_header.php';
$tabs = ['active' => 'Ativos', 'hidden' => 'Ocultos', 'removed' => 'Removidos', 'all' => 'Todos'];
$form = $editing ?? [];
$formAction = $editing ? 'update' : 'create';
$showForm = $editing || $result['action'] === 'create' || get_int('new') === 1;
?>
<div class="page-head"><h1>Gerir Produtos</h1><?php if (!$viewing): ?><a class="button" id="new-product" href="<?= e(url('admin/products.php?filter=' . $filter . '&new=1')) ?>">+ Adicionar Produto</a><?php endif; ?></div>
<?= errors_html($result['errors']) ?>

<?php if ($viewing): ?>
  <p><a href="<?= e(url('admin/products.php')) ?>">&larr; Produtos</a></p>
  <section class="panel detail-product">
    <?php $src = image_src($viewing['image_url']); if ($src): ?><img src="<?= e($src) ?>" alt="<?= e($viewing['name']) ?>"><?php endif; ?>
    <div>
      <h2><?= e($viewing['name']) ?></h2>
      <p><?= nl2br(e($viewing['description'])) ?></p>
      <dl class="detail-list">
        <div><dt>Preço</dt><dd><?= money($viewing['price']) ?></dd></div>
        <div><dt>Estado</dt><dd><?= $viewing['deleted_at'] !== null ? 'Removido em ' . e(fmt_datetime($viewing['deleted_at'])) : ((int)$viewing['active'] ? 'Visível no cardápio' : 'Oculto') ?></dd></div>
        <div><dt>Unidades vendidas</dt><dd><?= (int)$viewing['units_sold'] ?></dd></div>
        <div><dt>Avaliação média</dt><dd><?= (int)$viewing['review_count'] > 0 ? stars((float)$viewing['avg_rating']) . ' ' . e(number_format((float)$viewing['avg_rating'], 1, ',', '')) . ' (' . (int)$viewing['review_count'] . ')' : 'Sem avaliações' ?></dd></div>
      </dl>
      <a class="button" href="<?= e(url('admin/products.php?edit=' . (int)$viewing['id'])) ?>">Editar</a>
    </div>
  </section>
<?php else: ?>

<?php if ($showForm): ?>
<section class="panel" id="form-produto">
  <h2><?= $editing ? 'Editar produto' : 'Adicionar produto' ?></h2>
  <form method="post" action="<?= e(url('admin/products.php' . ($editing ? '?edit=' . (int)$editing['id'] : ''))) ?>" enctype="multipart/form-data">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="<?= $formAction ?>">
    <input type="hidden" name="filter" value="<?= e($filter) ?>">
    <?php if ($editing): ?><input type="hidden" name="product_id" value="<?= (int)$editing['id'] ?>"><?php endif; ?>
    <label>Nome<input name="name" maxlength="120" required value="<?= e(field_value('name', $form)) ?>"></label>
    <label>Descrição<textarea name="description" rows="3" maxlength="1000"><?= e(field_value('description', $form)) ?></textarea></label>
    <label>Categoria
      <select name="category" required>
        <?php foreach (product_categories() as $key => $label): ?>
          <option value="<?= e($key) ?>" <?= field_value('category', $form, 'tradicionais') === $key ? 'selected' : '' ?>><?= e($label) ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <label>Preço (MT)<input name="price" inputmode="decimal" required value="<?= e(field_value('price', $form)) ?>"></label>
    <?php if ($editing && ($src = image_src($editing['image_url']))): ?><img class="thumb-large" src="<?= e($src) ?>" alt="Fotografia atual"><?php endif; ?>
    <label><?= $editing ? 'Substituir fotografia' : 'Fotografia' ?><input type="file" name="image" accept="image/jpeg,image/png,image/webp" data-preview="#img-preview" data-max-bytes="<?= (int)MAX_UPLOAD_BYTES ?>"></label>
    <small class="small-note">JPG, PNG ou WEBP, até <?= e(upload_limit_label()) ?>.<?= $editing ? ' Deixa vazio para manter a atual.' : '' ?></small>
    <img id="img-preview" class="thumb-large" alt="Pré-visualização" hidden>
    <div class="form-actions"><button type="submit">Guardar</button><a href="<?= e(url('admin/products.php?filter=' . $filter)) ?>">Cancelar</a></div>
  </form>
</section>
<?php endif; ?>

<nav class="tabs" aria-label="Filtro">
  <?php foreach ($tabs as $key => $label): ?>
    <a href="<?= e(url('admin/products.php?filter=' . $key)) ?>" class="<?= $filter === $key ? 'is-active' : '' ?>"><?= e($label) ?> (<?= (int)$counts[$key] ?>)</a>
  <?php endforeach; ?>
</nav>

<?php if (!$products): ?><p class="empty">Nenhum produto neste filtro.</p><?php else: ?>
<div class="table-wrap">
  <table class="table-stack">
    <thead><tr><th>Foto</th><th>Nome</th><th>Categoria</th><th>Preço</th><th>Avaliação</th><th>Estado</th><th>Ações</th></tr></thead>
    <tbody>
    <?php foreach ($products as $p): $src = image_src($p['image_url']); ?>
      <tr>
        <td data-label="Foto"><?php if ($src): ?><img class="thumb" src="<?= e($src) ?>" alt=""><?php else: ?><span class="muted">&mdash;</span><?php endif; ?></td>
        <td data-label="Nome"><a href="<?= e(url('admin/products.php?view=' . (int)$p['id'])) ?>"><?= e($p['name']) ?></a></td>
        <td data-label="Categoria"><?= e(category_label($p['category'] ?? null)) ?></td>
        <td data-label="Preço"><?= money($p['price']) ?></td>
        <td data-label="Avaliação"><?= (int)$p['review_count'] > 0 ? e(number_format((float)$p['avg_rating'], 1, ',', '')) . ' (' . (int)$p['review_count'] . ')' : '<span class="muted">&mdash;</span>' ?></td>
        <td data-label="Estado"><?= $p['deleted_at'] !== null ? '<span class="badge badge-cancelled">Removido</span>' : ((int)$p['active'] ? '<span class="badge badge-delivered">Visível</span>' : '<span class="badge badge-pending">Oculto</span>') ?></td>
        <td class="cell-actions action-group">
          <a href="<?= e(url('admin/products.php?edit=' . (int)$p['id'])) ?>">Editar</a>
          <?php foreach ($p['deleted_at'] !== null || !(int)$p['active'] ? [['reactivate', 'Reativar', null]] : [['hide', 'Ocultar', null]] as [$act, $lbl]): ?>
            <form method="post" action="<?= e(url('admin/products.php')) ?>"><?= csrf_field() ?><input type="hidden" name="action" value="<?= $act ?>"><input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>"><input type="hidden" name="filter" value="<?= e($filter) ?>"><button type="submit" class="link-button"><?= $lbl ?></button></form>
          <?php endforeach; ?>
          <?php if ($p['deleted_at'] === null): ?>
            <form method="post" action="<?= e(url('admin/products.php')) ?>" data-confirm="Remover «<?= e($p['name']) ?>» do catálogo? O histórico das encomendas é preservado."><?= csrf_field() ?><input type="hidden" name="action" value="remove"><input type="hidden" name="product_id" value="<?= (int)$p['id'] ?>"><input type="hidden" name="filter" value="<?= e($filter) ?>"><button type="submit" class="button-link-danger">Remover</button></form>
          <?php endif; ?>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
  <p class="table-foot">Mostrando <?= count($products) ? '1 a ' . count($products) : '0' ?> de <?= count($products) ?> produtos</p>
</div>
<?php endif; ?>
<?php endif; ?>
<?php require __DIR__ . '/../layout/admin_footer.php'; ?>
