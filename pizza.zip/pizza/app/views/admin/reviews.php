<?php
$pageTitle = 'Avaliações'; $adminActive = 'reviews';
require __DIR__ . '/../layout/admin_header.php';
?>
<h1>Avaliações</h1>
<p class="lead"><?= (int)$summary['total'] ?> avaliações<?php if ($summary['average'] !== null): ?>, média de <?= e(number_format($summary['average'], 1, ',', '')) ?> de 5<?php endif; ?>.</p>
<form method="get" action="<?= e(url('admin/reviews.php')) ?>" class="filters">
  <label>Classificação
    <select name="rating" data-autosubmit>
      <option value="0">Todas</option>
      <?php for ($i = 5; $i >= 1; $i--): ?><option value="<?= $i ?>" <?= $rating === $i ? 'selected' : '' ?>><?= $i ?> <?= $i === 1 ? 'estrela' : 'estrelas' ?></option><?php endfor; ?>
    </select>
  </label>
  <button type="submit">Filtrar</button>
</form>
<?php if (!$reviews): ?><p class="empty">Ainda não há avaliações.</p><?php else: ?>
<div class="review-list">
  <?php foreach ($reviews as $r): ?>
    <article class="review-item">
      <?php if (!empty($r['photo_id'])): ?>
        <a href="<?= e(url('media.php?review=' . (int)$r['id'])) ?>" target="_blank" rel="noopener"><img class="review-thumb" src="<?= e(url('media.php?review=' . (int)$r['id'])) ?>" alt="Fotografia enviada por <?= e($r['customer_name']) ?>" loading="lazy"></a>
      <?php endif; ?>
      <div>
        <p><?= stars((float)$r['rating']) ?> <strong><?= e($r['product_name'] ?? 'Produto removido') ?></strong></p>
        <?php if (!empty($r['comment'])): ?><blockquote class="review-comment"><?= nl2br(e($r['comment'])) ?></blockquote><?php else: ?><p class="muted">Sem comentário.</p><?php endif; ?>
        <p class="small-note"><?= e($r['customer_name']) ?> (<?= e($r['customer_email']) ?>) &middot; <a href="<?= e(url('admin/orders.php?id=' . (int)$r['order_id'])) ?>">Encomenda #<?= (int)$r['order_id'] ?></a> &middot; <?= e(fmt_datetime($r['created_at'])) ?></p>
      </div>
    </article>
  <?php endforeach; ?>
</div>
<?= pagination_html($total, $perPage, $page, ['rating' => $rating]) ?>
<?php endif; ?>
<?php require __DIR__ . '/../layout/admin_footer.php'; ?>
