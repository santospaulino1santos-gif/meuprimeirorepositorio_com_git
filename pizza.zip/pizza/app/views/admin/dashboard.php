<?php
$pageTitle = 'Painel de Controlo'; $adminActive = 'dashboard';
require __DIR__ . '/../layout/admin_header.php';
$o = $stats['orders']; $s = $stats['sales'];
$topMax = max(1, ...array_map(static fn($t) => (int)$t['qty'], $top ?: [['qty' => 1]]));
// Gráfico de linhas (SVG) com os totais diários reais dos últimos 7 dias.
$chartW = 560; $chartH = 200; $padL = 8; $padB = 26; $padT = 12;
$maxTotal = max(1.0, ...array_map(static fn($d) => (float)$d['total'], $series));
$n = count($series);
$points = [];
foreach ($series as $i => $d) {
    $x = $padL + ($chartW - $padL * 2) * ($n > 1 ? $i / ($n - 1) : 0);
    $y = $padT + ($chartH - $padB - $padT) * (1 - ((float)$d['total'] / $maxTotal));
    $points[] = [round($x, 1), round($y, 1), $d];
}
$polyline = implode(' ', array_map(static fn($p) => $p[0] . ',' . $p[1], $points));
?>
<h1>Painel de Controlo</h1>
<?php if (distance_mode_manual()): ?>
  <div class="alert warning" role="status">Modo sem mapa ativo (<code>DISTANCE_MODE = 'manual'</code>): os clientes escolhem a zona de entrega; a distância não é medida pela Google.</div>
<?php elseif (!$configured): ?>
  <div class="alert warning" role="alert">A chave da Google Routes API não está configurada (<code>app/config/config.local.php</code>). Os clientes não conseguem finalizar encomendas até isto estar resolvido.</div>
<?php endif; ?>

<section class="stat-grid">
  <div class="stat"><span>Total de pedidos</span><strong><?= (int)$o['total'] ?></strong></div>
  <div class="stat"><span>Clientes registados</span><strong><?= (int)$stats['customers'] ?></strong></div>
  <div class="stat"><span>Promoções ativas</span><strong><?= (int)$stats['promotions'] ?></strong></div>
  <div class="stat stat-accent"><span>Receita total (entregues)</span><strong><?= money($s['delivered_total']) ?></strong></div>
</section>
<section class="stat-grid stat-grid-small">
  <div class="stat"><span>Pendentes</span><strong><?= (int)$o['pending'] ?></strong></div>
  <div class="stat"><span>Em preparação</span><strong><?= (int)$o['preparing'] ?></strong></div>
  <div class="stat"><span>Entregues</span><strong><?= (int)$o['delivered'] ?></strong></div>
  <div class="stat"><span>Produtos ativos</span><strong><?= (int)$stats['products'] ?></strong></div>
</section>

<div class="dash-grid">
  <section class="panel">
    <div class="panel-head"><h2>Pedidos recentes</h2><a href="<?= e(url('admin/orders.php')) ?>">Ver todos</a></div>
    <?php if (!$recent): ?><p class="empty">Ainda não há encomendas.</p><?php else: ?>
    <div class="table-wrap"><table class="table-stack">
      <thead><tr><th>Cliente</th><th>Produtos</th><th>Total</th><th>Estado</th><th>Data</th></tr></thead>
      <tbody><?php foreach ($recent as $r): ?>
        <tr>
          <td data-label="Cliente"><a href="<?= e(url('admin/orders.php?id=' . (int)$r['id'])) ?>"><?= e($r['customer']) ?></a></td>
          <td data-label="Produtos"><?= e(mb_strimwidth((string)$r['products'], 0, 40, '…')) ?></td>
          <td data-label="Total"><?= money($r['total']) ?></td>
          <td data-label="Estado"><?= status_badge((string)$r['status']) ?></td>
          <td data-label="Data"><?= e(fmt_date($r['created_at'])) ?></td>
        </tr>
      <?php endforeach; ?></tbody>
    </table></div>
    <?php endif; ?>
  </section>

  <section class="panel">
    <h2>Vendas (últimos 7 dias)</h2>
    <p class="small-note">Valor das encomendas não canceladas, por dia de criação.</p>
    <svg class="chart" viewBox="0 0 <?= $chartW ?> <?= $chartH ?>" role="img" aria-label="Gráfico de vendas dos últimos 7 dias">
      <line x1="<?= $padL ?>" y1="<?= $chartH - $padB ?>" x2="<?= $chartW - $padL ?>" y2="<?= $chartH - $padB ?>" class="chart-axis"/>
      <polyline points="<?= e($polyline) ?>" class="chart-line"/>
      <?php foreach ($points as [$px, $py, $d]): ?>
        <circle cx="<?= $px ?>" cy="<?= $py ?>" r="4" class="chart-dot"><title><?= e($d['label']) ?>: <?= e(money($d['total'])) ?> (<?= (int)$d['count'] ?> encomendas)</title></circle>
        <text x="<?= $px ?>" y="<?= $chartH - 8 ?>" text-anchor="middle" class="chart-label"><?= e($d['label']) ?></text>
      <?php endforeach; ?>
    </svg>
    <p class="small-note">Máximo no período: <?= money($maxTotal > 1 ? $maxTotal : 0) ?></p>
  </section>
</div>

<div class="dash-grid">
  <section class="panel">
    <h2>Resumo de vendas</h2>
    <dl class="summary-list">
      <div><dt>Receita concluída (entregues)</dt><dd><?= money($s['delivered_total']) ?></dd></div>
      <div><dt>&nbsp;&nbsp;produtos</dt><dd><?= money($s['delivered_subtotal']) ?></dd></div>
      <div><dt>&nbsp;&nbsp;taxas de entrega</dt><dd><?= money($s['delivered_fees']) ?></dd></div>
      <div><dt>Em curso (pendentes a em entrega)</dt><dd><?= money($s['open_total']) ?></dd></div>
      <div><dt>Avaliações</dt><dd><?= (int)$stats['reviews']['total'] ?><?= $stats['reviews']['average'] !== null ? ' (média ' . e(number_format($stats['reviews']['average'], 1, ',', '')) . ')' : '' ?></dd></div>
    </dl>
  </section>
  <section class="panel">
    <h2>Pizzas mais vendidas</h2>
    <?php if (!$top): ?><p class="empty">Ainda não há vendas registadas.</p>
    <?php else: ?>
      <ul class="bars">
        <?php foreach ($top as $t): ?>
          <li><span class="bar-label"><?= e($t['product_name']) ?></span>
            <span class="bar"><span style="width: <?= (int)round((int)$t['qty'] / $topMax * 100) ?>%"></span></span>
            <span class="bar-value"><?= (int)$t['qty'] ?> un.</span></li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </section>
</div>
<?php require __DIR__ . '/../layout/admin_footer.php'; ?>
