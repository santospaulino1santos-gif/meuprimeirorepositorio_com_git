<?php
declare(strict_types=1);

/**
 * Cálculo da distância de condução (km) entre a cozinha e o destino, com a Google Routes API.
 * Nunca inventa valores: sem chave ou com erro da API devolve ok=false e uma mensagem clara.
 */

function distance_mode_manual(): bool {
    return DISTANCE_MODE === 'manual';
}
function distance_service_configured(): bool {
    return distance_mode_manual() || trim((string)GOOGLE_MAPS_API_KEY) !== '';
}

function kitchen_origin(): ?array {
    if (is_numeric(KITCHEN_LAT) && is_numeric(KITCHEN_LNG)) {
        return ['location' => ['latLng' => ['latitude' => (float)KITCHEN_LAT, 'longitude' => (float)KITCHEN_LNG]]];
    }
    if (trim((string)KITCHEN_ADDRESS) !== '') {
        return ['address' => (string)KITCHEN_ADDRESS];
    }
    return null;
}

/**
 * @return array{ok:bool, km:?float, code:string, message:string}
 */
function calculate_route_distance(string $address, ?float $lat = null, ?float $lng = null): array {
    $fail = static fn(string $code, string $message): array => ['ok' => false, 'km' => null, 'code' => $code, 'message' => $message];

    if (!distance_service_configured()) {
        return $fail('not_configured', 'O cálculo da distância ainda não está configurado: falta a chave da Google Maps Routes API. A encomenda não pode ser finalizada até a pizzaria concluir esta configuração.');
    }
    $origin = kitchen_origin();
    if ($origin === null) {
        return $fail('origin_missing', 'O ponto de referência da cozinha não está configurado. A encomenda não pode ser finalizada até a pizzaria concluir esta configuração.');
    }
    if (!function_exists('curl_init')) {
        app_log('Distância: a extensão cURL do PHP não está ativa.');
        return $fail('no_curl', 'O servidor não tem a extensão cURL ativa, necessária para calcular a distância. A pizzaria precisa de corrigir a configuração.');
    }

    $destination = ($lat !== null && $lng !== null)
        ? ['location' => ['latLng' => ['latitude' => $lat, 'longitude' => $lng]]]
        : ['address' => $address];

    $payload = [
        'origin' => $origin,
        'destination' => $destination,
        'travelMode' => 'DRIVE',
        'routingPreference' => 'TRAFFIC_UNAWARE',
        'units' => 'METRIC',
        'languageCode' => 'pt-PT',
        'regionCode' => (string)DELIVERY_REGION_CODE,
    ];

    $ch = curl_init('https://routes.googleapis.com/directions/v2:computeRoutes');
    $options = [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'X-Goog-Api-Key: ' . GOOGLE_MAPS_API_KEY,
            'X-Goog-FieldMask: routes.distanceMeters',
        ],
        CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
        CURLOPT_CONNECTTIMEOUT => 8,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ];
    if ((string)CURL_CA_BUNDLE !== '' && is_file((string)CURL_CA_BUNDLE)) {
        $options[CURLOPT_CAINFO] = (string)CURL_CA_BUNDLE;
    }
    curl_setopt_array($ch, $options);
    $response = curl_exec($ch);
    $status = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlError = curl_error($ch);
    curl_close($ch);

    if ($response === false) {
        app_log('Distância: falha de rede/cURL: ' . $curlError);
        return $fail('network', 'Não foi possível contactar o serviço de distância. Tenta novamente dentro de instantes.');
    }
    $data = json_decode((string)$response, true);
    if ($status !== 200 || !is_array($data)) {
        $apiMessage = is_array($data) ? (string)($data['error']['message'] ?? '') : '';
        $apiStatus = is_array($data) ? (string)($data['error']['status'] ?? '') : '';
        app_log('Distância: Routes API respondeu HTTP ' . $status . ' ' . $apiStatus . ' ' . $apiMessage);
        if (in_array($status, [400], true) && $apiStatus === 'INVALID_ARGUMENT') {
            return $fail('api', 'Não foi possível localizar este endereço. Confirma o endereço (inclui bairro e cidade) ou usa a opção "Usar a minha localização".');
        }
        if (in_array($status, [401, 403], true)) {
            return $fail('api', 'O serviço de distância recusou a configuração atual (chave inválida ou Routes API não ativada). A pizzaria precisa de corrigir a configuração.');
        }
        return $fail('api', 'Não foi possível calcular a distância neste momento. Tenta novamente dentro de instantes.');
    }
    $meters = $data['routes'][0]['distanceMeters'] ?? null;
    if (!is_numeric($meters)) {
        return $fail('no_route', 'Não foi encontrado um percurso até este endereço. Confirma o endereço ou usa a opção "Usar a minha localização".');
    }
    $km = round(((float)$meters) / 1000, 2);
    if ($km < 0 || $km > 5000) {
        return $fail('no_route', 'A distância calculada não é válida. Confirma o endereço.');
    }
    return ['ok' => true, 'km' => $km, 'code' => 'ok', 'message' => ''];
}
