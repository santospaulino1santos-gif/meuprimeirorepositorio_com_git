<?php
declare(strict_types=1);

/** Regista mensagens internas em storage/logs/app.log (nunca mostradas ao utilizador final). */
function app_log(string $message): void {
    $dir = STORAGE_PATH . '/logs';
    if (!is_dir($dir)) {
        @mkdir($dir, 0750, true);
    }
    @file_put_contents($dir . '/app.log', '[' . date('Y-m-d H:i:s') . '] ' . $message . PHP_EOL, FILE_APPEND | LOCK_EX);
}
