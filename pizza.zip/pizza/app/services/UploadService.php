<?php
declare(strict_types=1);

/**
 * Validação e armazenamento de imagens enviadas.
 * - valida erro de upload, tamanho, MIME real (finfo), extensão e conteúdo (getimagesize);
 * - gera sempre um nome aleatório com extensão fixa (jpg/png/webp);
 * - imagens públicas (produtos/promoções) ficam em uploads/ (onde o .htaccess impede execução);
 * - fotografias de avaliações ficam em storage/ (fora da pasta pública) e são servidas por media.php.
 */

function allowed_image_types(): array {
    return ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
}
function upload_limit_label(): string {
    return (string)(int)round(MAX_UPLOAD_BYTES / 1048576) . ' MB';
}

/** Devolve null se nenhum ficheiro foi enviado; lança RuntimeException (mensagem para o utilizador) se for inválido. */
function validate_image_upload(string $field): ?array {
    if (!isset($_FILES[$field]) || !is_array($_FILES[$field])) {
        return null;
    }
    $file = $_FILES[$field];
    if (is_array($file['error'] ?? null)) {
        throw new RuntimeException('Envio de ficheiro inválido.');
    }
    $error = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);
    if ($error === UPLOAD_ERR_NO_FILE) {
        return null;
    }
    if ($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE) {
        throw new RuntimeException('A imagem é demasiado grande. O máximo permitido é ' . upload_limit_label() . '.');
    }
    if ($error !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Falha no envio da imagem. Tenta novamente.');
    }
    $tmp = (string)($file['tmp_name'] ?? '');
    if ($tmp === '' || !is_uploaded_file($tmp)) {
        throw new RuntimeException('Envio de ficheiro inválido.');
    }
    $size = (int)($file['size'] ?? 0);
    if ($size <= 0 || $size > MAX_UPLOAD_BYTES) {
        throw new RuntimeException('A imagem não pode ultrapassar ' . upload_limit_label() . '.');
    }
    $types = allowed_image_types();
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp);
    if (!is_string($mime) || !isset($types[$mime])) {
        throw new RuntimeException('Formato inválido. Usa uma imagem JPG, PNG ou WEBP.');
    }
    $extension = strtolower(pathinfo((string)($file['name'] ?? ''), PATHINFO_EXTENSION));
    if ($extension === 'jpeg') {
        $extension = 'jpg';
    }
    if ($extension !== $types[$mime]) {
        throw new RuntimeException('A extensão do ficheiro não corresponde ao formato. Usa JPG, PNG ou WEBP.');
    }
    $info = @getimagesize($tmp);
    if ($info === false || ($info['mime'] ?? '') !== $mime) {
        throw new RuntimeException('O ficheiro não é uma imagem válida.');
    }
    $width = (int)$info[0];
    $height = (int)$info[1];
    if ($width < 1 || $height < 1 || $width * $height > 40000000) {
        throw new RuntimeException('As dimensões da imagem não são aceites.');
    }
    return ['tmp' => $tmp, 'mime' => $mime, 'ext' => $types[$mime], 'size' => $size];
}

/** Guarda em uploads/<products|promotions>/ e devolve o caminho relativo. */
function store_public_image(string $field, string $folder): ?string {
    if (!in_array($folder, ['products', 'promotions'], true)) {
        throw new InvalidArgumentException('Pasta de upload inválida.');
    }
    $image = validate_image_upload($field);
    if ($image === null) {
        return null;
    }
    $directory = PUBLIC_PATH . '/uploads/' . $folder;
    if (!is_dir($directory) && !mkdir($directory, 0755, true) && !is_dir($directory)) {
        throw new RuntimeException('Não foi possível preparar a pasta de imagens.');
    }
    $name = bin2hex(random_bytes(16)) . '.' . $image['ext'];
    if (!move_uploaded_file($image['tmp'], $directory . '/' . $name)) {
        throw new RuntimeException('Não foi possível guardar a imagem.');
    }
    @chmod($directory . '/' . $name, 0644);
    return 'uploads/' . $folder . '/' . $name;
}

/** Guarda em storage/<folder>/ (fora da pasta pública). Devolve nome do ficheiro, MIME e tamanho. */
function store_private_image(string $field, string $folder): ?array {
    if ($folder !== 'review_photos') {
        throw new InvalidArgumentException('Pasta de upload inválida.');
    }
    $image = validate_image_upload($field);
    if ($image === null) {
        return null;
    }
    $directory = STORAGE_PATH . '/' . $folder;
    if (!is_dir($directory) && !mkdir($directory, 0750, true) && !is_dir($directory)) {
        throw new RuntimeException('Não foi possível preparar a pasta de imagens.');
    }
    $name = bin2hex(random_bytes(16)) . '.' . $image['ext'];
    if (!move_uploaded_file($image['tmp'], $directory . '/' . $name)) {
        throw new RuntimeException('Não foi possível guardar a imagem.');
    }
    @chmod($directory . '/' . $name, 0640);
    return ['file' => $name, 'mime' => $image['mime'], 'size' => $image['size']];
}

/** Remove uma imagem pública enviada pela aplicação (ignora URLs externas e caminhos inesperados). */
function delete_public_upload(?string $relativePath): void {
    if ($relativePath === null || !preg_match('#^uploads/(products|promotions)/[a-f0-9]{32}\.(jpg|png|webp)$#', $relativePath)) {
        return;
    }
    $file = PUBLIC_PATH . '/' . $relativePath;
    if (is_file($file)) {
        @unlink($file);
    }
}

function private_file_path(string $folder, string $name): ?string {
    if ($folder !== 'review_photos' || !preg_match('/^[a-f0-9]{32}\.(jpg|png|webp)$/', $name)) {
        return null;
    }
    $file = STORAGE_PATH . '/' . $folder . '/' . $name;
    return is_file($file) ? $file : null;
}
function delete_private_file(string $folder, string $name): void {
    $file = private_file_path($folder, $name);
    if ($file !== null) {
        @unlink($file);
    }
}
