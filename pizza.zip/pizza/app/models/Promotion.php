<?php
declare(strict_types=1);

function now_sql(): string {
    return date('Y-m-d H:i:s');
}

/** Promoções ativas e dentro do prazo, para a área do cliente. */
function active_promotions(): array {
    $now = now_sql();
    $st = db()->prepare("SELECT pr.*, p.name AS product_name, p.price AS product_price
        FROM promotions pr
        LEFT JOIN products p ON p.id = pr.product_id
        WHERE pr.active = 1
          AND (pr.starts_at IS NULL OR pr.starts_at <= ?)
          AND (pr.ends_at IS NULL OR pr.ends_at >= ?)
          AND (pr.product_id IS NULL OR (p.active = 1 AND p.deleted_at IS NULL))
        ORDER BY pr.id DESC");
    $st->execute([$now, $now]);
    return $st->fetchAll();
}
/** Melhor preço promocional vigente por produto: [product_id => linha da promoção]. */
function active_product_promotions(): array {
    $now = now_sql();
    $st = db()->prepare("SELECT * FROM promotions
        WHERE active = 1 AND product_id IS NOT NULL AND promo_price IS NOT NULL
          AND (starts_at IS NULL OR starts_at <= ?)
          AND (ends_at IS NULL OR ends_at >= ?)
        ORDER BY promo_price DESC, id ASC");
    $st->execute([$now, $now]);
    $map = [];
    foreach ($st->fetchAll() as $row) {
        $map[(int)$row['product_id']] = $row;   // a última (preço mais baixo) prevalece
    }
    return $map;
}
function all_promotions(): array {
    return db()->query("SELECT pr.*, p.name AS product_name, p.price AS product_price
        FROM promotions pr LEFT JOIN products p ON p.id = pr.product_id
        ORDER BY pr.id DESC")->fetchAll();
}
function promotion_by_id(int $id): ?array {
    $st = db()->prepare('SELECT * FROM promotions WHERE id = ?');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}
/** @return array{0:string,1:string} [rótulo, classe CSS] */
function promotion_state(array $promotion): array {
    if (!(int)$promotion['active']) {
        return ['Desativada', 'cancelled'];
    }
    $now = time();
    if (!empty($promotion['starts_at']) && strtotime((string)$promotion['starts_at']) > $now) {
        return ['Agendada', 'pending'];
    }
    if (!empty($promotion['ends_at']) && strtotime((string)$promotion['ends_at']) < $now) {
        return ['Expirada', 'cancelled'];
    }
    return ['Ativa', 'delivered'];
}

/** @return array{0:?string,1:bool} [valor 'Y-m-d H:i:s' ou null, válido] */
function parse_datetime_local(string $value): array {
    if ($value === '') {
        return [null, true];
    }
    $date = DateTime::createFromFormat('Y-m-d\TH:i', $value);
    $errors = DateTime::getLastErrors();
    if ($date === false || ($errors && ($errors['warning_count'] > 0 || $errors['error_count'] > 0))) {
        return [null, false];
    }
    return [$date->format('Y-m-d H:i:00'), true];
}

/**
 * Valida os dados do formulário de promoção.
 * @return array{0:array,1:string[]} [dados limpos, erros]
 */
function validate_promotion_input(): array {
    $errors = [];
    $title = post_string('title');
    $description = post_string('description');
    $conditions = post_string('conditions');
    $productId = post_int('product_id', 0);
    $priceRaw = post_string('promo_price');
    $active = isset($_POST['active']) ? 1 : 0;

    if (mb_strlen($title) < 3 || mb_strlen($title) > 150) {
        $errors[] = 'O título deve ter entre 3 e 150 caracteres.';
    }
    if (mb_strlen($description) > 1000) {
        $errors[] = 'A descrição não pode ter mais de 1000 caracteres.';
    }
    if (mb_strlen($conditions) > 500) {
        $errors[] = 'As condições não podem ter mais de 500 caracteres.';
    }

    $promoPrice = null;
    if ($priceRaw !== '') {
        $promoPrice = parse_money($priceRaw);
        if ($promoPrice === null || $promoPrice <= 0) {
            $errors[] = 'O preço promocional é inválido. Usa um valor positivo, por exemplo 299,00.';
            $promoPrice = null;
        }
    }
    $product = null;
    if ($productId > 0) {
        $product = product_admin_by_id($productId);
        if (!$product || $product['deleted_at'] !== null) {
            $errors[] = 'O produto escolhido não existe ou foi removido.';
            $productId = 0;
        }
    }
    if ($productId > 0 && $promoPrice === null && $priceRaw === '') {
        $errors[] = 'Indica o preço promocional do produto escolhido.';
    }
    if ($productId < 1 && $promoPrice !== null) {
        $errors[] = 'O preço promocional só pode ser usado quando escolhes um produto.';
        $promoPrice = null;
    }
    if ($product && $promoPrice !== null && $promoPrice >= (float)$product['price']) {
        $errors[] = 'O preço promocional (' . money($promoPrice) . ') tem de ser inferior ao preço atual do produto (' . money($product['price']) . ').';
    }

    [$startsAt, $startsOk] = parse_datetime_local(post_string('starts_at'));
    [$endsAt, $endsOk] = parse_datetime_local(post_string('ends_at'));
    if (!$startsOk) {
        $errors[] = 'A data de início não é válida.';
    }
    if (!$endsOk) {
        $errors[] = 'A data de fim não é válida.';
    }
    if ($startsAt !== null && $endsAt !== null && $startsAt > $endsAt) {
        $errors[] = 'A data de fim tem de ser posterior à data de início.';
    }
    if ($active && $endsAt !== null && strtotime($endsAt) < time()) {
        $errors[] = 'A data de fim já passou. Escolhe uma data futura ou desativa a promoção.';
    }

    return [[
        'title' => $title,
        'description' => $description,
        'conditions' => $conditions,
        'product_id' => $productId > 0 ? $productId : null,
        'promo_price' => $promoPrice,
        'starts_at' => $startsAt,
        'ends_at' => $endsAt,
        'active' => $active,
    ], $errors];
}

function save_promotion(array $c, ?string $image): int {
    $st = db()->prepare('INSERT INTO promotions (title, description, conditions, image_url, product_id, promo_price, starts_at, ends_at, active) VALUES (?,?,?,?,?,?,?,?,?)');
    $st->execute([$c['title'], $c['description'], $c['conditions'], $image, $c['product_id'], $c['promo_price'], $c['starts_at'], $c['ends_at'], $c['active']]);
    return (int)db()->lastInsertId();
}
function update_promotion(int $id, array $c, ?string $image): void {
    $sql = 'UPDATE promotions SET title=?, description=?, conditions=?, product_id=?, promo_price=?, starts_at=?, ends_at=?, active=?';
    $params = [$c['title'], $c['description'], $c['conditions'], $c['product_id'], $c['promo_price'], $c['starts_at'], $c['ends_at'], $c['active']];
    if ($image !== null) {
        $sql .= ', image_url=?';
        $params[] = $image;
    }
    $sql .= ' WHERE id=?';
    $params[] = $id;
    db()->prepare($sql)->execute($params);
}
function set_promotion_active(int $id, bool $active): void {
    db()->prepare('UPDATE promotions SET active = ? WHERE id = ?')->execute([$active ? 1 : 0, $id]);
}
function delete_promotion(int $id): void {
    db()->prepare('DELETE FROM promotions WHERE id = ?')->execute([$id]);
}
