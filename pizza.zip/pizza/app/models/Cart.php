<?php
declare(strict_types=1);

const CART_MAX_QTY = 30;

function cart_raw(): array {
    $cart = $_SESSION['cart'] ?? [];
    return is_array($cart) ? $cart : [];
}
function cart_count(): int {
    return (int)array_sum(array_map('intval', cart_raw()));
}
function cart_add(int $productId, int $quantity): void {
    $current = (int)($_SESSION['cart'][$productId] ?? 0);
    $_SESSION['cart'][$productId] = max(1, min(CART_MAX_QTY, $current + $quantity));
}
function cart_set(int $productId, int $quantity): void {
    if ($quantity < 1) {
        cart_remove($productId);
        return;
    }
    if (isset($_SESSION['cart'][$productId])) {
        $_SESSION['cart'][$productId] = min(CART_MAX_QTY, $quantity);
    }
}
function cart_remove(int $productId): void {
    unset($_SESSION['cart'][$productId]);
}
function cart_clear(): void {
    unset($_SESSION['cart']);
}

/**
 * Calcula as linhas do carrinho sempre a partir da base de dados (preços e disponibilidade).
 * Os valores guardados na sessão são apenas IDs e quantidades.
 * @return array{items:array,subtotal:float,missing:int[]}
 */
function cart_lines(array $cart): array {
    $products = products_by_ids(array_map('intval', array_keys($cart)));
    $items = [];
    $missing = [];
    $subtotal = 0.0;
    foreach ($cart as $id => $quantity) {
        $id = (int)$id;
        $quantity = max(1, min(CART_MAX_QTY, (int)$quantity));
        if (!isset($products[$id])) {
            $missing[] = $id;
            continue;
        }
        $product = $products[$id];
        $line = round($product['effective_price'] * $quantity, 2);
        $items[] = [
            'id' => $id,
            'name' => $product['name'],
            'image_url' => $product['image_url'],
            'list_price' => $product['list_price'],
            'unit_price' => $product['effective_price'],
            'quantity' => $quantity,
            'line_total' => $line,
            'promotion' => $product['promotion'],
        ];
        $subtotal += $line;
    }
    return ['items' => $items, 'subtotal' => round($subtotal, 2), 'missing' => $missing];
}
/** Resumo do carrinho da sessão; remove os produtos que já não estão disponíveis. */
function cart_summary(): array {
    $summary = cart_lines(cart_raw());
    foreach ($summary['missing'] as $id) {
        unset($_SESSION['cart'][$id]);
    }
    return $summary;
}
