<?php
declare(strict_types=1);

const LOGIN_WINDOW_SECONDS = 900;     // 15 minutos
const LOGIN_MAX_PER_ACCOUNT_IP = 5;   // falhas do mesmo email a partir do mesmo IP
const LOGIN_MAX_PER_IP = 20;          // falhas de qualquer email a partir do mesmo IP

function client_ip(): string {
    $ip = (string)($_SERVER['REMOTE_ADDR'] ?? '');
    return filter_var($ip, FILTER_VALIDATE_IP) ? $ip : '0.0.0.0';
}
function login_is_blocked(string $email, string $ip): bool {
    $since = date('Y-m-d H:i:s', time() - LOGIN_WINDOW_SECONDS);
    $st = db()->prepare('SELECT COUNT(*) FROM login_attempts WHERE success = 0 AND ip = ? AND email = ? AND attempted_at >= ?');
    $st->execute([$ip, $email, $since]);
    if ((int)$st->fetchColumn() >= LOGIN_MAX_PER_ACCOUNT_IP) {
        return true;
    }
    $st = db()->prepare('SELECT COUNT(*) FROM login_attempts WHERE success = 0 AND ip = ? AND attempted_at >= ?');
    $st->execute([$ip, $since]);
    return (int)$st->fetchColumn() >= LOGIN_MAX_PER_IP;
}
function record_login_attempt(string $email, string $ip, bool $success): void {
    $st = db()->prepare('INSERT INTO login_attempts (email, ip, success, attempted_at) VALUES (?, ?, ?, ?)');
    $st->execute([mb_substr($email, 0, 190), $ip, $success ? 1 : 0, date('Y-m-d H:i:s')]);
    if (random_int(1, 50) === 1) {
        $old = db()->prepare('DELETE FROM login_attempts WHERE attempted_at < ?');
        $old->execute([date('Y-m-d H:i:s', time() - 7 * 86400)]);
    }
}
function clear_failed_logins(string $email, string $ip): void {
    $st = db()->prepare('DELETE FROM login_attempts WHERE success = 0 AND ip = ? AND email = ?');
    $st->execute([$ip, $email]);
}
