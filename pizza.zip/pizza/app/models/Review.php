<?php
declare(strict_types=1);

function review_for_order(int $orderId): ?array {
    $st = db()->prepare('SELECT r.*, rp.id AS photo_id
        FROM reviews r LEFT JOIN review_photos rp ON rp.review_id = r.id
        WHERE r.order_id = ? LIMIT 1');
    $st->execute([$orderId]);
    return $st->fetch() ?: null;
}

/** Dados da fotografia de uma avaliação e do seu proprietário (para media.php). */
function review_photo_by_review(int $reviewId): ?array {
    $st = db()->prepare('SELECT rp.file_name, rp.mime_type, rp.size_bytes, r.user_id
        FROM review_photos rp JOIN reviews r ON r.id = rp.review_id
        WHERE rp.review_id = ? LIMIT 1');
    $st->execute([$reviewId]);
    return $st->fetch() ?: null;
}

/**
 * Regista a avaliação numa transação. Regras verificadas aqui, com a encomenda bloqueada:
 * pertence ao utilizador, está entregue, ainda não foi avaliada e o item escolhido pertence à encomenda.
 * A chave única uq_reviews_order impede duplicados mesmo em pedidos simultâneos.
 *
 * @param array{file:string,mime:string,size:int}|null $photo
 */
function create_review(int $userId, int $orderId, int $orderItemId, int $rating, string $comment, ?array $photo): int {
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $st = $pdo->prepare('SELECT id, user_id, status FROM orders WHERE id = ? FOR UPDATE');
        $st->execute([$orderId]);
        $order = $st->fetch();
        if (!$order || (int)$order['user_id'] !== $userId) {
            throw new RuntimeException('Encomenda não encontrada.');
        }
        if ($order['status'] !== 'delivered') {
            throw new RuntimeException('Só podes avaliar uma encomenda depois de ela ser marcada como entregue.');
        }
        $st = $pdo->prepare('SELECT id FROM reviews WHERE order_id = ?');
        $st->execute([$orderId]);
        if ($st->fetch()) {
            throw new RuntimeException('Esta encomenda já foi avaliada.');
        }
        $st = $pdo->prepare('SELECT product_id, product_name FROM order_items WHERE id = ? AND order_id = ?');
        $st->execute([$orderItemId, $orderId]);
        $item = $st->fetch();
        if (!$item) {
            throw new RuntimeException('Escolhe a pizza que queres avaliar.');
        }
        $insert = $pdo->prepare('INSERT INTO reviews (user_id, order_id, product_id, product_name, rating, comment) VALUES (?,?,?,?,?,?)');
        $insert->execute([$userId, $orderId, $item['product_id'], $item['product_name'], $rating, $comment !== '' ? $comment : null]);
        $reviewId = (int)$pdo->lastInsertId();
        if ($photo !== null) {
            $insertPhoto = $pdo->prepare('INSERT INTO review_photos (review_id, file_name, mime_type, size_bytes) VALUES (?,?,?,?)');
            $insertPhoto->execute([$reviewId, $photo['file'], $photo['mime'], $photo['size']]);
        }
        $pdo->commit();
        return $reviewId;
    } catch (PDOException $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        if ((int)($e->errorInfo[1] ?? 0) === 1062) {
            throw new RuntimeException('Esta encomenda já foi avaliada.');
        }
        throw $e;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

function admin_reviews_count(int $rating): int {
    $sql = 'SELECT COUNT(*) FROM reviews' . ($rating >= 1 && $rating <= 5 ? ' WHERE rating = ' . $rating : '');
    return (int)db()->query($sql)->fetchColumn();
}
function admin_reviews(int $rating, int $limit, int $offset): array {
    $where = ($rating >= 1 && $rating <= 5) ? ' WHERE r.rating = ' . $rating : '';
    $limit = max(1, $limit);
    $offset = max(0, $offset);
    return db()->query("SELECT r.id, r.order_id, r.rating, r.comment, r.product_name, r.created_at,
            u.name AS customer_name, u.email AS customer_email, rp.id AS photo_id
        FROM reviews r
        JOIN users u ON u.id = r.user_id
        LEFT JOIN review_photos rp ON rp.review_id = r.id" . $where . "
        ORDER BY r.created_at DESC, r.id DESC LIMIT $limit OFFSET $offset")->fetchAll();
}
function reviews_summary(): array {
    $row = db()->query('SELECT COUNT(*) AS total, ROUND(AVG(rating), 1) AS average FROM reviews')->fetch();
    return ['total' => (int)$row['total'], 'average' => $row['average'] !== null ? (float)$row['average'] : null];
}
