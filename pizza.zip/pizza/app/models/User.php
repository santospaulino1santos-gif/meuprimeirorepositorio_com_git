<?php
declare(strict_types=1);

function user_by_email(string $email): ?array {
    $st = db()->prepare('SELECT * FROM users WHERE email = ? LIMIT 1');
    $st->execute([$email]);
    return $st->fetch() ?: null;
}
function user_by_id(int $id): ?array {
    $st = db()->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}
/** Cria sempre um cliente. A função "admin" nunca é atribuída a partir de formulários. */
function create_user(string $name, string $email, string $phone, string $password): int {
    $st = db()->prepare("INSERT INTO users (name,email,phone,password_hash,role) VALUES (?,?,?,?, 'customer')");
    $st->execute([$name, $email, $phone !== '' ? $phone : null, password_hash($password, PASSWORD_DEFAULT)]);
    return (int)db()->lastInsertId();
}
function update_user_password_hash(int $id, string $hash): void {
    $st = db()->prepare('UPDATE users SET password_hash = ? WHERE id = ?');
    $st->execute([$hash, $id]);
}

function customers_search_clause(string $search, array &$params): string {
    if ($search === '') {
        return '';
    }
    $like = '%' . addcslashes($search, '%_\\') . '%';
    array_push($params, $like, $like, $like);
    return ' AND (u.name LIKE ? OR u.email LIKE ? OR u.phone LIKE ?)';
}
function customers_count(string $search = ''): int {
    $params = [];
    $where = customers_search_clause($search, $params);
    $st = db()->prepare("SELECT COUNT(*) FROM users u WHERE u.role = 'customer'" . $where);
    $st->execute($params);
    return (int)$st->fetchColumn();
}
function customers_list(string $search, int $limit, int $offset): array {
    $params = [];
    $where = customers_search_clause($search, $params);
    $limit = max(1, $limit);
    $offset = max(0, $offset);
    $sql = "SELECT u.id, u.name, u.email, u.phone, u.created_at,
                (SELECT COUNT(*) FROM orders o WHERE o.user_id = u.id) AS orders_count,
                (SELECT COALESCE(SUM(o.total), 0) FROM orders o WHERE o.user_id = u.id AND o.status <> 'cancelled') AS total_spent,
                (SELECT MAX(o.created_at) FROM orders o WHERE o.user_id = u.id) AS last_order_at
            FROM users u
            WHERE u.role = 'customer'" . $where . "
            ORDER BY u.created_at DESC, u.id DESC
            LIMIT $limit OFFSET $offset";
    $st = db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}
function customer_by_id(int $id): ?array {
    $st = db()->prepare("SELECT u.id, u.name, u.email, u.phone, u.created_at,
            (SELECT COUNT(*) FROM orders o WHERE o.user_id = u.id) AS orders_count,
            (SELECT COALESCE(SUM(o.total), 0) FROM orders o WHERE o.user_id = u.id AND o.status <> 'cancelled') AS total_spent,
            (SELECT COUNT(*) FROM reviews r WHERE r.user_id = u.id) AS reviews_count
        FROM users u WHERE u.id = ? AND u.role = 'customer'");
    $st->execute([$id]);
    return $st->fetch() ?: null;
}
