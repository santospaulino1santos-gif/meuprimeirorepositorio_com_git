<?php
declare(strict_types=1);

/** Junta preço efetivo (com promoção vigente) a uma linha de produto. */
function attach_pricing(array $product, array $promotions): array {
    $price = (float)$product['price'];
    $product['list_price'] = $price;
    $product['effective_price'] = $price;
    $product['promotion'] = null;
    $promo = $promotions[(int)$product['id']] ?? null;
    if ($promo !== null && $promo['promo_price'] !== null && (float)$promo['promo_price'] < $price) {
        $product['effective_price'] = (float)$promo['promo_price'];
        $product['promotion'] = $promo;
    }
    return $product;
}

const PRODUCT_RATING_COLUMNS = "(SELECT ROUND(AVG(r.rating), 1) FROM reviews r WHERE r.product_id = p.id) AS avg_rating,
    (SELECT COUNT(*) FROM reviews r WHERE r.product_id = p.id) AS review_count";

/** Cardápio: apenas produtos ativos e não removidos, com preços promocionais e classificação média. */
function catalog_products(): array {
    $rows = db()->query('SELECT p.*, ' . PRODUCT_RATING_COLUMNS . ' FROM products p
        WHERE p.active = 1 AND p.deleted_at IS NULL ORDER BY p.name ASC, p.id ASC')->fetchAll();
    $promotions = active_product_promotions();
    return array_map(static fn(array $row): array => attach_pricing($row, $promotions), $rows);
}
function featured_products(int $limit = 4): array {
    $products = catalog_products();
    usort($products, static function (array $a, array $b): int {
        $byPromo = ((int)($b['promotion'] !== null)) <=> ((int)($a['promotion'] !== null));
        if ($byPromo !== 0) {
            return $byPromo;
        }
        $byRating = ((float)($b['avg_rating'] ?? 0)) <=> ((float)($a['avg_rating'] ?? 0));
        return $byRating !== 0 ? $byRating : ((int)$b['id'] <=> (int)$a['id']);
    });
    return array_slice($products, 0, $limit);
}
/** Produtos vendáveis por ID (ativos e não removidos): [id => produto com preço efetivo]. */
function products_by_ids(array $ids): array {
    $ids = array_values(array_unique(array_filter(array_map('intval', $ids), static fn(int $id): bool => $id > 0)));
    if (!$ids) {
        return [];
    }
    $in = implode(',', array_fill(0, count($ids), '?'));
    $st = db()->prepare("SELECT p.* FROM products p WHERE p.id IN ($in) AND p.active = 1 AND p.deleted_at IS NULL");
    $st->execute($ids);
    $promotions = active_product_promotions();
    $map = [];
    foreach ($st->fetchAll() as $row) {
        $map[(int)$row['id']] = attach_pricing($row, $promotions);
    }
    return $map;
}
function product_by_id(int $id): ?array {
    return products_by_ids([$id])[$id] ?? null;
}

/* ---------- Administração ---------- */

function product_admin_by_id(int $id): ?array {
    $st = db()->prepare('SELECT p.*, ' . PRODUCT_RATING_COLUMNS . ',
            (SELECT COALESCE(SUM(oi.quantity), 0) FROM order_items oi JOIN orders o ON o.id = oi.order_id
                WHERE oi.product_id = p.id AND o.status <> \'cancelled\') AS units_sold
        FROM products p WHERE p.id = ?');
    $st->execute([$id]);
    return $st->fetch() ?: null;
}
function product_filter_sql(string $filter): string {
    return match ($filter) {
        'hidden' => 'p.active = 0 AND p.deleted_at IS NULL',
        'removed' => 'p.deleted_at IS NOT NULL',
        'all' => '1 = 1',
        default => 'p.active = 1 AND p.deleted_at IS NULL',
    };
}
function admin_products(string $filter): array {
    return db()->query('SELECT p.*, ' . PRODUCT_RATING_COLUMNS . ' FROM products p WHERE ' . product_filter_sql($filter) . ' ORDER BY p.name ASC, p.id ASC')->fetchAll();
}
function admin_product_counts(): array {
    $row = db()->query("SELECT
            COALESCE(SUM(active = 1 AND deleted_at IS NULL), 0) AS active_count,
            COALESCE(SUM(active = 0 AND deleted_at IS NULL), 0) AS hidden_count,
            COALESCE(SUM(deleted_at IS NOT NULL), 0) AS removed_count,
            COUNT(*) AS all_count
        FROM products")->fetch();
    return ['active' => (int)$row['active_count'], 'hidden' => (int)$row['hidden_count'], 'removed' => (int)$row['removed_count'], 'all' => (int)$row['all_count']];
}

/**
 * Valida o formulário de produto.
 * @return array{0:array,1:string[]}
 */
function validate_product_input(): array {
    $errors = [];
    $name = post_string('name');
    $description = post_string('description');
    $price = parse_money(post_string('price'));
    $category = post_string('category');
    if (!isset(product_categories()[$category])) {
        $errors[] = 'Escolhe uma categoria válida.';
    }
    if (mb_strlen($name) < 2 || mb_strlen($name) > 120) {
        $errors[] = 'O nome deve ter entre 2 e 120 caracteres.';
    }
    if (mb_strlen($description) > 1000) {
        $errors[] = 'A descrição não pode ter mais de 1000 caracteres.';
    }
    if ($price === null || $price <= 0) {
        $errors[] = 'O preço é inválido. Usa um valor positivo, por exemplo 350,00.';
    }
    return [['name' => $name, 'description' => $description, 'price' => $price, 'category' => $category], $errors];
}
function save_product(string $name, string $description, float $price, string $category, ?string $image): int {
    $st = db()->prepare('INSERT INTO products (name, description, category, price, image_url, active) VALUES (?,?,?,?,?,1)');
    $st->execute([$name, $description, $category, $price, $image]);
    return (int)db()->lastInsertId();
}
function update_product(int $id, string $name, string $description, float $price, string $category, ?string $image): void {
    if ($image !== null) {
        db()->prepare('UPDATE products SET name=?, description=?, category=?, price=?, image_url=? WHERE id=?')->execute([$name, $description, $category, $price, $image, $id]);
    } else {
        db()->prepare('UPDATE products SET name=?, description=?, category=?, price=? WHERE id=?')->execute([$name, $description, $category, $price, $id]);
    }
}
function hide_product(int $id): void {
    db()->prepare('UPDATE products SET active = 0 WHERE id = ? AND deleted_at IS NULL')->execute([$id]);
}
/** Reativa um produto oculto ou restaura um removido. */
function reactivate_product(int $id): void {
    db()->prepare('UPDATE products SET active = 1, deleted_at = NULL WHERE id = ?')->execute([$id]);
}
/** Remoção lógica: o produto desaparece do catálogo mas o histórico das encomendas é preservado. */
function remove_product(int $id): void {
    db()->prepare('UPDATE products SET active = 0, deleted_at = ? WHERE id = ?')->execute([now_sql(), $id]);
}
