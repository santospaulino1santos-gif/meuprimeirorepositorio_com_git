<?php
declare(strict_types=1);

/** Estatísticas do dashboard: todas calculadas a partir da base de dados. */
function dashboard_stats(): array {
    $pdo = db();
    $o = $pdo->query("SELECT COUNT(*) AS total,
            COALESCE(SUM(status = 'pending'), 0) AS pending,
            COALESCE(SUM(status = 'confirmed'), 0) AS confirmed,
            COALESCE(SUM(status = 'preparing'), 0) AS preparing,
            COALESCE(SUM(status = 'on_delivery'), 0) AS on_delivery,
            COALESCE(SUM(status = 'delivered'), 0) AS delivered,
            COALESCE(SUM(status = 'cancelled'), 0) AS cancelled
        FROM orders")->fetch();

    $sales = $pdo->query("SELECT
            COALESCE(SUM(CASE WHEN status = 'delivered' THEN total END), 0) AS delivered_total,
            COALESCE(SUM(CASE WHEN status = 'delivered' THEN subtotal END), 0) AS delivered_subtotal,
            COALESCE(SUM(CASE WHEN status = 'delivered' THEN delivery_fee END), 0) AS delivered_fees,
            COALESCE(SUM(CASE WHEN status IN ('pending','confirmed','preparing','on_delivery') THEN total END), 0) AS open_total
        FROM orders")->fetch();

    $customers = (int)$pdo->query("SELECT COUNT(*) FROM users WHERE role = 'customer'")->fetchColumn();
    $products = (int)$pdo->query('SELECT COUNT(*) FROM products WHERE active = 1 AND deleted_at IS NULL')->fetchColumn();

    $now = now_sql();
    $st = $pdo->prepare('SELECT COUNT(*) FROM promotions WHERE active = 1 AND (starts_at IS NULL OR starts_at <= ?) AND (ends_at IS NULL OR ends_at >= ?)');
    $st->execute([$now, $now]);
    $promotions = (int)$st->fetchColumn();

    return [
        'orders' => array_map('intval', $o),
        'sales' => array_map('floatval', $sales),
        'customers' => $customers,
        'products' => $products,
        'promotions' => $promotions,
        'reviews' => reviews_summary(),
    ];
}

/** Últimos $days dias (inclui hoje): nº de encomendas não canceladas e valor total por dia. */
function daily_orders_series(int $days = 7): array {
    $start = new DateTimeImmutable('today -' . ($days - 1) . ' days');
    $st = db()->prepare("SELECT DATE(created_at) AS d, COUNT(*) AS c, COALESCE(SUM(total), 0) AS t
        FROM orders WHERE created_at >= ? AND status <> 'cancelled' GROUP BY DATE(created_at)");
    $st->execute([$start->format('Y-m-d 00:00:00')]);
    $byDay = [];
    foreach ($st->fetchAll() as $row) {
        $byDay[(string)$row['d']] = ['count' => (int)$row['c'], 'total' => (float)$row['t']];
    }
    $series = [];
    for ($i = 0; $i < $days; $i++) {
        $day = $start->modify("+$i days");
        $key = $day->format('Y-m-d');
        $series[] = ['label' => $day->format('d/m'), 'count' => $byDay[$key]['count'] ?? 0, 'total' => $byDay[$key]['total'] ?? 0.0];
    }
    return $series;
}
function top_products(int $limit = 5): array {
    $limit = max(1, $limit);
    return db()->query("SELECT oi.product_name, SUM(oi.quantity) AS qty, SUM(oi.line_total) AS revenue
        FROM order_items oi JOIN orders o ON o.id = oi.order_id
        WHERE o.status <> 'cancelled'
        GROUP BY oi.product_name ORDER BY qty DESC, revenue DESC LIMIT $limit")->fetchAll();
}

/** Últimas encomendas com os produtos resumidos (para o dashboard). */
function recent_orders(int $limit = 5): array {
    $limit = max(1, $limit);
    return db()->query("SELECT o.id, o.total, o.status, o.created_at, COALESCE(o.customer_name, u.name) AS customer,
            (SELECT GROUP_CONCAT(oi.product_name ORDER BY oi.id SEPARATOR ', ') FROM order_items oi WHERE oi.order_id = o.id) AS products
        FROM orders o JOIN users u ON u.id = o.user_id
        ORDER BY o.created_at DESC, o.id DESC LIMIT $limit")->fetchAll();
}
