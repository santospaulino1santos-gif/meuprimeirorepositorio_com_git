<?php
declare(strict_types=1);

/**
 * Cria a encomenda numa transação. Preços, quantidades e disponibilidade são recalculados
 * a partir da base de dados; a taxa vem da faixa validada no servidor ($quote['rate_id'], $quote['fee']).
 *
 * @param array $form  dados de entrega já validados (name, phone, address, reference, notes, lat, lng)
 * @param array $quote resultado de checkout_compute_quote() com ok=true
 */
function create_order(int $userId, array $form, array $quote, array $cart): int {
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $lines = cart_lines($cart);
        if (!$lines['items']) {
            throw new RuntimeException('O carrinho está vazio.');
        }
        if ($lines['missing']) {
            throw new RuntimeException('Alguns produtos do carrinho já não estão disponíveis. Revê o carrinho.');
        }
        if (abs($lines['subtotal'] - (float)$quote['subtotal']) > 0.009) {
            throw new RuntimeException('Os preços do carrinho foram atualizados. Revê o resumo e confirma novamente.');
        }
        $fee = round((float)$quote['fee'], 2);
        $total = round($lines['subtotal'] + $fee, 2);

        $insert = $pdo->prepare('INSERT INTO orders
            (user_id, customer_name, phone, address, address_reference, latitude, longitude, notes, distance_km, distance_source, subtotal, delivery_fee, total, delivery_rate_id, payment_method, status)
            VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
        $insert->execute([
            $userId,
            $form['name'],
            $form['phone'],
            $form['address'],
            $form['reference'] !== '' ? $form['reference'] : null,
            $form['lat'] !== '' ? $form['lat'] : null,
            $form['lng'] !== '' ? $form['lng'] : null,
            $form['notes'] !== '' ? $form['notes'] : null,
            $quote['distance_km'],
            ($quote['source'] ?? 'google') === 'manual' ? 'manual' : 'google',
            $lines['subtotal'],
            $fee,
            $total,
            $quote['rate_id'],
            'cash_on_delivery',
            'pending',
        ]);
        $orderId = (int)$pdo->lastInsertId();

        $item = $pdo->prepare('INSERT INTO order_items (order_id, product_id, product_name, list_price, promotion_id, unit_price, quantity, line_total) VALUES (?,?,?,?,?,?,?,?)');
        foreach ($lines['items'] as $line) {
            $item->execute([
                $orderId,
                $line['id'],
                $line['name'],
                $line['list_price'],
                $line['promotion']['id'] ?? null,
                $line['unit_price'],
                $line['quantity'],
                $line['line_total'],
            ]);
        }
        $pdo->commit();
        return $orderId;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

function payment_method_label(string $method): string {
    return $method === 'cash_on_delivery' ? 'Dinheiro no momento da entrega' : $method;
}

/* ---------- Cliente ---------- */

function orders_for_user(int $userId): array {
    $st = db()->prepare('SELECT o.*,
            (SELECT COALESCE(SUM(oi.quantity), 0) FROM order_items oi WHERE oi.order_id = o.id) AS items_count,
            r.id AS review_id, r.rating AS review_rating
        FROM orders o
        LEFT JOIN reviews r ON r.order_id = o.id
        WHERE o.user_id = ?
        ORDER BY o.created_at DESC, o.id DESC');
    $st->execute([$userId]);
    return $st->fetchAll();
}
/** Só devolve a encomenda se pertencer ao utilizador indicado. */
function order_for_user(int $orderId, int $userId): ?array {
    $st = db()->prepare('SELECT * FROM orders WHERE id = ? AND user_id = ?');
    $st->execute([$orderId, $userId]);
    return $st->fetch() ?: null;
}
function order_items(int $orderId): array {
    $st = db()->prepare('SELECT * FROM order_items WHERE order_id = ? ORDER BY id ASC');
    $st->execute([$orderId]);
    return $st->fetchAll();
}

/* ---------- Administração ---------- */

function orders_filter_clause(string $status, string $search, array &$params): string {
    $where = ' WHERE 1 = 1';
    if ($status !== '' && isset(order_statuses()[$status])) {
        $where .= ' AND o.status = ?';
        $params[] = $status;
    }
    if ($search !== '') {
        $like = '%' . addcslashes($search, '%_\\') . '%';
        $where .= ' AND (o.id = ? OR u.name LIKE ? OR u.email LIKE ? OR o.customer_name LIKE ? OR o.phone LIKE ?)';
        array_push($params, ctype_digit($search) ? (int)$search : 0, $like, $like, $like, $like);
    }
    return $where;
}
function admin_orders_count(string $status, string $search): int {
    $params = [];
    $where = orders_filter_clause($status, $search, $params);
    $st = db()->prepare('SELECT COUNT(*) FROM orders o JOIN users u ON u.id = o.user_id' . $where);
    $st->execute($params);
    return (int)$st->fetchColumn();
}
function admin_orders(string $status, string $search, int $limit, int $offset): array {
    $params = [];
    $where = orders_filter_clause($status, $search, $params);
    $limit = max(1, $limit);
    $offset = max(0, $offset);
    $st = db()->prepare("SELECT o.*, COALESCE(o.customer_name, u.name) AS display_name, u.email AS account_email,
            (SELECT COALESCE(SUM(oi.quantity), 0) FROM order_items oi WHERE oi.order_id = o.id) AS items_count
        FROM orders o JOIN users u ON u.id = o.user_id" . $where . "
        ORDER BY o.created_at DESC, o.id DESC LIMIT $limit OFFSET $offset");
    $st->execute($params);
    return $st->fetchAll();
}
function order_by_id(int $orderId): ?array {
    $st = db()->prepare('SELECT o.*, u.name AS account_name, u.email AS account_email
        FROM orders o JOIN users u ON u.id = o.user_id WHERE o.id = ?');
    $st->execute([$orderId]);
    return $st->fetch() ?: null;
}
function admin_order_counts_by_status(): array {
    $counts = array_fill_keys(array_keys(order_statuses()), 0);
    foreach (db()->query('SELECT status, COUNT(*) AS c FROM orders GROUP BY status')->fetchAll() as $row) {
        $counts[(string)$row['status']] = (int)$row['c'];
    }
    return $counts;
}

/**
 * Atualiza o estado respeitando as transições permitidas.
 * @return array{0:bool,1:string} [sucesso, mensagem]
 */
function update_order_status(int $orderId, string $newStatus): array {
    if (!isset(order_statuses()[$newStatus])) {
        return [false, 'Estado inválido.'];
    }
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $st = $pdo->prepare('SELECT status FROM orders WHERE id = ? FOR UPDATE');
        $st->execute([$orderId]);
        $current = $st->fetchColumn();
        if ($current === false) {
            $pdo->rollBack();
            return [false, 'Encomenda não encontrada.'];
        }
        if (!in_array($newStatus, allowed_next_statuses((string)$current), true)) {
            $pdo->rollBack();
            return [false, 'Não é possível passar de "' . status_label((string)$current) . '" para "' . status_label($newStatus) . '".'];
        }
        if ($newStatus === 'delivered') {
            $up = $pdo->prepare('UPDATE orders SET status = ?, delivered_at = ? WHERE id = ?');
            $up->execute([$newStatus, now_sql(), $orderId]);
        } else {
            $up = $pdo->prepare('UPDATE orders SET status = ? WHERE id = ?');
            $up->execute([$newStatus, $orderId]);
        }
        $pdo->commit();
        return [true, 'Estado atualizado para "' . status_label($newStatus) . '".'];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}
