<?php
declare(strict_types=1);

/** Faixas ordenadas: primeiro as que têm limite superior (crescente), por fim a aberta (sem limite). */
function delivery_rates(): array {
    return db()->query('SELECT * FROM delivery_rates ORDER BY (max_km IS NULL) ASC, max_km ASC, id ASC')->fetchAll();
}
/** Faixa aplicável: a primeira cujo limite superior cobre a distância (a última não tem limite). */
function delivery_rate_for_distance(float $km): ?array {
    foreach (delivery_rates() as $rate) {
        if ($rate['max_km'] === null || $km <= (float)$rate['max_km']) {
            return $rate;
        }
    }
    return null;
}
/** Texto da faixa: "Até 5 km", "De 5 a 10 km", "Mais de 10 km". */
function delivery_rate_label(array $rate, ?array $previous): string {
    $format = static fn($v): string => rtrim(rtrim(number_format((float)$v, 2, ',', ''), '0'), ',');
    if ($rate['max_km'] === null) {
        return 'Mais de ' . $format($previous['max_km'] ?? 0) . ' km';
    }
    if ($previous === null) {
        return 'Até ' . $format($rate['max_km']) . ' km';
    }
    return 'De ' . $format($previous['max_km']) . ' a ' . $format($rate['max_km']) . ' km';
}
function delivery_rates_labeled(): array {
    $rates = delivery_rates();
    $previous = null;
    foreach ($rates as $i => $rate) {
        $rates[$i]['label'] = delivery_rate_label($rate, $previous);
        $previous = $rate;
    }
    return $rates;
}

/**
 * Valida e guarda as faixas (limites superiores e valores). A última faixa não tem limite.
 * @return string[] erros (vazio se guardou)
 */
function save_delivery_rates_from_post(): array {
    $rates = delivery_rates();
    $errors = [];
    $maxInput = $_POST['max_km'] ?? [];
    $feeInput = $_POST['fee'] ?? [];
    if (!is_array($maxInput) || !is_array($feeInput)) {
        return ['Dados inválidos.'];
    }
    $updates = [];
    $previousMax = 0.0;
    $last = count($rates) - 1;
    foreach ($rates as $i => $rate) {
        $id = (int)$rate['id'];
        $fee = parse_money((string)($feeInput[$id] ?? ''));
        if ($fee === null) {
            $errors[] = 'Faixa ' . ($i + 1) . ': o valor da taxa é inválido (use um número, por exemplo 80 ou 80,00).';
        }
        $max = null;
        if ($i < $last) {
            $raw = str_replace(',', '.', trim((string)($maxInput[$id] ?? '')));
            if (!preg_match('/^\d{1,4}(\.\d{1,2})?$/', $raw) || (float)$raw <= $previousMax) {
                $errors[] = 'Faixa ' . ($i + 1) . ': o limite em km tem de ser um número maior do que o limite da faixa anterior (' . rtrim(rtrim(number_format($previousMax, 2, ',', ''), '0'), ',') . ' km).';
            } else {
                $max = round((float)$raw, 2);
            }
        }
        $updates[] = ['id' => $id, 'min' => $previousMax, 'max' => $max, 'fee' => $fee];
        if ($max !== null) {
            $previousMax = $max;
        }
    }
    if ($errors) {
        return $errors;
    }
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $st = $pdo->prepare('UPDATE delivery_rates SET min_km = ?, max_km = ?, fee = ? WHERE id = ?');
        foreach ($updates as $u) {
            $st->execute([$u['min'], $u['max'], $u['fee'], $u['id']]);
        }
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
    return [];
}
