<?php
declare(strict_types=1);

/* ---------- Escape, URLs e redirecionamentos ---------- */

function e(mixed $value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}
function is_https(): bool {
    return (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (string)($_SERVER['SERVER_PORT'] ?? '') === '443';
}
function url(string $path = ''): string {
    return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
}
function asset(string $path): string {
    $path = ltrim($path, '/');
    $file = PUBLIC_PATH . '/assets/' . $path;
    $version = is_file($file) ? (string)filemtime($file) : '1';
    return url('assets/' . $path) . '?v=' . $version;
}
function redirect(string $path): void {
    header('Location: ' . url($path));
    exit;
}
function abort(int $code, string $message = ''): void {
    http_response_code($code);
    $titles = [403 => 'Acesso não autorizado', 404 => 'Página não encontrada', 419 => 'Pedido inválido', 500 => 'Ocorreu um erro'];
    $errorTitle = $titles[$code] ?? 'Ocorreu um erro';
    $errorMessage = $message;
    require __DIR__ . '/views/pages/error.php';
    exit;
}

/* ---------- Mensagens (flash) e valores de formulários ---------- */

function flash(string $message, string $type = 'info'): void {
    $_SESSION['flash'] = ['message' => $message, 'type' => $type];
}
function take_flash(): ?array {
    $value = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $value;
}
function post_string(string $key): string {
    $value = $_POST[$key] ?? '';
    return is_string($value) ? trim($value) : '';
}
function post_int(string $key, int $default = 0): int {
    $value = $_POST[$key] ?? null;
    return (is_string($value) || is_int($value)) && preg_match('/^-?\d{1,9}$/', (string)$value) ? (int)$value : $default;
}
function get_int(string $key, int $default = 0): int {
    $value = $_GET[$key] ?? null;
    return is_string($value) && preg_match('/^\d{1,9}$/', $value) ? (int)$value : $default;
}
function get_string(string $key): string {
    $value = $_GET[$key] ?? '';
    return is_string($value) ? trim($value) : '';
}
/** Valor de um campo: o enviado (POST) se existir, senão o valor existente na base de dados. */
function field_value(string $key, array $existing = [], string $default = ''): string {
    if (is_post() && isset($_POST[$key]) && is_string($_POST[$key])) {
        return $_POST[$key];
    }
    $value = $existing[$key] ?? $default;
    return $value === null ? '' : (string)$value;
}
function is_post(): bool {
    return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
}
/** Converte "12,50" ou "12.50" em float. Devolve null se o formato for inválido. */
function parse_money(string $value): ?float {
    $value = str_replace(["\u{00A0}", ' '], '', trim($value));
    $value = str_replace(',', '.', $value);
    if (!preg_match('/^\d{1,7}(\.\d{1,2})?$/', $value)) {
        return null;
    }
    return round((float)$value, 2);
}

/* ---------- CSRF ---------- */

function csrf_token(): string {
    if (empty($_SESSION['csrf']) || !is_string($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}
function csrf_field(): string {
    return '<input type="hidden" name="_csrf" value="' . e(csrf_token()) . '">';
}
function verify_csrf(): void {
    $sent = $_POST['_csrf'] ?? '';
    if (!is_string($sent) || !hash_equals(csrf_token(), $sent)) {
        abort(419, 'A sessão expirou ou o pedido não é válido. Volta à página anterior, atualiza-a e tenta novamente.');
    }
}

/* ---------- Utilizador e permissões ---------- */

function current_user(bool $refresh = false): ?array {
    static $cache = false;
    if ($refresh) {
        $cache = false;
    }
    if ($cache !== false) {
        return $cache;
    }
    $id = (int)($_SESSION['uid'] ?? 0);
    if ($id < 1) {
        return $cache = null;
    }
    $user = user_by_id($id);
    if (!$user) {
        unset($_SESSION['uid']);
        return $cache = null;
    }
    return $cache = [
        'id' => (int)$user['id'],
        'name' => (string)$user['name'],
        'email' => (string)$user['email'],
        'phone' => (string)($user['phone'] ?? ''),
        'role' => (string)$user['role'],
    ];
}
function is_admin(): bool {
    $user = current_user();
    return $user !== null && $user['role'] === 'admin';
}
function require_login(): void {
    if (current_user()) {
        return;
    }
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
        $target = basename((string)($_SERVER['SCRIPT_NAME'] ?? '')) . (!empty($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : '');
        if (preg_match('/^(checkout|orders|order)\.php(\?[A-Za-z0-9=&_%\-]{0,80})?$/', $target)) {
            $_SESSION['after_login'] = $target;
        }
    }
    flash('Inicia sessão para continuar.', 'warning');
    redirect('login.php');
}
function require_admin(): void {
    require_login();
    if (!is_admin()) {
        abort(403, 'Esta área é reservada à administração.');
    }
}

/* ---------- Formatação ---------- */

function money(float|int|string|null $amount): string {
    return number_format((float)$amount, 2, ',', "\u{00A0}") . "\u{00A0}MT";
}
function fmt_km(float|int|string|null $km): string {
    return number_format((float)$km, 2, ',', "\u{00A0}") . "\u{00A0}km";
}
function fmt_datetime(?string $value): string {
    $time = $value ? strtotime($value) : false;
    return $time ? date('d/m/Y H:i', $time) : '—';
}
function fmt_date(?string $value): string {
    $time = $value ? strtotime($value) : false;
    return $time ? date('d/m/Y', $time) : '—';
}
/** 'Y-m-d H:i:s' → valor para <input type="datetime-local"> */
function datetime_local_value(?string $value): string {
    $time = $value ? strtotime($value) : false;
    return $time ? date('Y-m-d\TH:i', $time) : '';
}
function stars(float $rating): string {
    $full = max(0, min(5, (int)round($rating)));
    return '<span class="stars" role="img" aria-label="' . e(number_format($rating, 1, ',', '')) . ' de 5 estrelas">'
        . str_repeat('★', $full) . '<span class="stars-off">' . str_repeat('★', 5 - $full) . '</span></span>';
}
function image_src(?string $path): ?string {
    if ($path === null || $path === '') {
        return null;
    }
    return preg_match('#^https?://#i', $path) ? $path : url($path);
}
function maps_link(?string $lat, ?string $lng): ?string {
    if ($lat === null || $lng === null || $lat === '' || $lng === '' || !is_numeric($lat) || !is_numeric($lng)) {
        return null;
    }
    return 'https://www.google.com/maps/search/?api=1&query=' . rawurlencode($lat . ',' . $lng);
}

/** Abre a navegação até ao ponto de entrega, usando a localização actual do entregador como origem. */
function maps_directions_link(?string $lat, ?string $lng): ?string {
    if ($lat === null || $lng === null || $lat === '' || $lng === '' || !is_numeric($lat) || !is_numeric($lng)) {
        return null;
    }
    return 'https://www.google.com/maps/dir/?api=1&destination=' . rawurlencode($lat . ',' . $lng) . '&travelmode=driving';
}

/* ---------- Estados das encomendas ---------- */

function order_statuses(): array {
    return [
        'pending' => 'Pendente',
        'confirmed' => 'Confirmada',
        'preparing' => 'Em preparação',
        'on_delivery' => 'Saiu para entrega',
        'delivered' => 'Entregue',
        'cancelled' => 'Cancelada',
    ];
}
function status_label(string $status): string {
    return order_statuses()[$status] ?? $status;
}
function status_badge(string $status): string {
    return '<span class="badge badge-' . e($status) . '">' . e(status_label($status)) . '</span>';
}
/** Transições permitidas. Entregue e Cancelada são estados finais. */
function allowed_next_statuses(string $status): array {
    return match ($status) {
        'pending' => ['confirmed', 'preparing', 'cancelled'],
        'confirmed' => ['preparing', 'cancelled'],
        'preparing' => ['on_delivery', 'cancelled'],
        'on_delivery' => ['delivered', 'cancelled'],
        default => [],
    };
}

/* ---------- Categorias do cardápio ---------- */

function product_categories(): array {
    return ['tradicionais' => 'Tradicionais', 'especiais' => 'Especiais', 'premium' => 'Premium'];
}
function category_label(?string $category): string {
    return product_categories()[(string)$category] ?? 'Tradicionais';
}

/* ---------- Paginação ---------- */

function page_number(): int {
    return max(1, get_int('page', 1));
}
function pagination_html(int $total, int $perPage, int $page, array $query = []): string {
    $pages = (int)ceil($total / max(1, $perPage));
    if ($pages <= 1) {
        return '';
    }
    $base = basename((string)($_SERVER['SCRIPT_NAME'] ?? ''));
    $html = '<nav class="pagination" aria-label="Paginação">';
    for ($i = 1; $i <= $pages; $i++) {
        $href = $base . '?' . http_build_query(array_merge($query, ['page' => $i]));
        $html .= $i === $page
            ? '<span class="current" aria-current="page">' . $i . '</span>'
            : '<a href="' . e($href) . '">' . $i . '</a>';
    }
    return $html . '</nav>';
}

/* ---------- Mensagens de erro de formulários ---------- */

function errors_html(array $errors): string {
    if (!$errors) {
        return '';
    }
    $html = '<div class="alert error" role="alert"><ul>';
    foreach ($errors as $error) {
        $html .= '<li>' . e($error) . '</li>';
    }
    return $html . '</ul></div>';
}
