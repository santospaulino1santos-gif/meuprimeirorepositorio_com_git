<?php
declare(strict_types=1);

/**
 * Processa as ações do painel de promoções.
 * @return array{errors:string[],action:?string}
 */
function handle_admin_promotions(): array {
    $result = ['errors' => [], 'action' => null];
    if (!is_post()) {
        return $result;
    }
    verify_csrf();
    $action = post_string('action');
    $id = post_int('promotion_id', 0);
    $back = 'admin/promotions.php';

    try {
        if ($action === 'create') {
            [$data, $errors] = validate_promotion_input();
            if ($errors) {
                return ['errors' => $errors, 'action' => $action];
            }
            $image = store_public_image('image', 'promotions');
            save_promotion($data, $image);
            flash('Promoção criada.', 'success');
            redirect($back);
        }

        $promotion = $id > 0 ? promotion_by_id($id) : null;
        if (!$promotion) {
            flash('Promoção não encontrada.', 'error');
            redirect($back);
        }

        if ($action === 'update') {
            [$data, $errors] = validate_promotion_input();
            if ($errors) {
                return ['errors' => $errors, 'action' => $action];
            }
            $image = store_public_image('image', 'promotions');
            update_promotion($id, $data, $image);
            if ($image !== null) {
                delete_public_upload($promotion['image_url']);
            }
            flash('Promoção atualizada.', 'success');
            redirect($back);
        }
        if ($action === 'activate') {
            if (!empty($promotion['ends_at']) && strtotime((string)$promotion['ends_at']) < time()) {
                flash('Esta promoção já terminou. Edita a data de fim antes de a ativar.', 'error');
            } else {
                set_promotion_active($id, true);
                flash('Promoção ativada.', 'success');
            }
        } elseif ($action === 'deactivate') {
            set_promotion_active($id, false);
            flash('Promoção desativada. Deixou de aparecer aos clientes.', 'success');
        } elseif ($action === 'delete') {
            delete_promotion($id);
            delete_public_upload($promotion['image_url']);
            flash('Promoção removida.', 'success');
        }
    } catch (RuntimeException $e) {
        return ['errors' => [$e->getMessage()], 'action' => $action];
    }
    redirect($back);
}
