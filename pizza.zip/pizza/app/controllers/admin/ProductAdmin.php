<?php
declare(strict_types=1);

const ADMIN_PRODUCT_FILTERS = ['active', 'hidden', 'removed', 'all'];

function admin_product_filter(): string {
    $filter = get_string('filter');
    return in_array($filter, ADMIN_PRODUCT_FILTERS, true) ? $filter : 'active';
}

/**
 * Processa as ações do painel de produtos.
 * @return array{errors:string[],action:?string} erros e a ação que falhou (para reabrir o formulário)
 */
function handle_admin_products(): array {
    $result = ['errors' => [], 'action' => null];
    if (!is_post()) {
        return $result;
    }
    verify_csrf();
    $action = post_string('action');
    $id = post_int('product_id', 0);
    $filter = in_array(post_string('filter'), ADMIN_PRODUCT_FILTERS, true) ? post_string('filter') : 'active';
    $back = 'admin/products.php?filter=' . $filter;

    try {
        if ($action === 'create') {
            [$data, $errors] = validate_product_input();
            if ($errors) {
                return ['errors' => $errors, 'action' => $action];
            }
            $image = store_public_image('image', 'products');
            save_product($data['name'], $data['description'], (float)$data['price'], $data['category'], $image);
            flash('Produto adicionado ao cardápio.', 'success');
            redirect($back);
        }

        $product = $id > 0 ? product_admin_by_id($id) : null;
        if (!$product) {
            flash('Produto não encontrado.', 'error');
            redirect($back);
        }

        if ($action === 'update') {
            [$data, $errors] = validate_product_input();
            if ($errors) {
                return ['errors' => $errors, 'action' => $action];
            }
            $image = store_public_image('image', 'products');
            update_product($id, $data['name'], $data['description'], (float)$data['price'], $data['category'], $image);
            if ($image !== null) {
                delete_public_upload($product['image_url']);
            }
            flash('Produto atualizado.', 'success');
            redirect($back);
        }
        if ($action === 'hide') {
            hide_product($id);
            flash('«' . $product['name'] . '» foi ocultado do cardápio.', 'success');
        } elseif ($action === 'reactivate') {
            reactivate_product($id);
            flash('«' . $product['name'] . '» voltou a estar disponível no cardápio.', 'success');
        } elseif ($action === 'remove') {
            remove_product($id);
            flash('«' . $product['name'] . '» foi removido do catálogo. O histórico das encomendas foi preservado.', 'success');
        }
    } catch (RuntimeException $e) {
        return ['errors' => [$e->getMessage()], 'action' => $action];
    }
    redirect($back);
}
