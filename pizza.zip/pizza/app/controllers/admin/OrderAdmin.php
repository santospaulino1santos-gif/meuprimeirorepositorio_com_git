<?php
declare(strict_types=1);

function handle_admin_order_status(): void {
    if (!is_post()) {
        return;
    }
    verify_csrf();
    $orderId = post_int('order_id', 0);
    if ($orderId < 1 || post_string('action') !== 'status') {
        abort(404, 'Encomenda não encontrada.');
    }
    [$ok, $message] = update_order_status($orderId, post_string('status'));
    flash($message, $ok ? 'success' : 'error');
    $returnList = post_string('return') === 'list';
    redirect($returnList ? 'admin/orders.php' : 'admin/orders.php?id=' . $orderId);
}
