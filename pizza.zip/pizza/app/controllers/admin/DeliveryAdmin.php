<?php
declare(strict_types=1);

/** @return string[] erros (vazio se não houve submissão; redireciona após guardar) */
function handle_admin_delivery(): array {
    if (!is_post()) {
        return [];
    }
    verify_csrf();
    $errors = save_delivery_rates_from_post();
    if ($errors) {
        return $errors;
    }
    flash('Taxas de entrega guardadas. Aplicam-se às próximas encomendas; as anteriores mantêm os valores da altura da compra.', 'success');
    redirect('admin/delivery.php');
}
