<?php
declare(strict_types=1);

function handle_cart_post(): void {
    if (!is_post()) {
        return;
    }
    verify_csrf();
    $action = post_string('action');
    $return = post_string('return');
    $returnPage = in_array($return, ['menu.php', 'index.php'], true) ? $return : 'cart.php';
    $productId = post_int('product_id', 0);

    switch ($action) {
        case 'add':
            $quantity = max(1, min(CART_MAX_QTY, post_int('quantity', 1)));
            $product = $productId > 0 ? product_by_id($productId) : null;
            if (!$product) {
                flash('Este produto já não está disponível.', 'error');
                redirect($returnPage);
            }
            cart_add($productId, $quantity);
            flash('«' . $product['name'] . '» adicionada ao carrinho.', 'success');
            redirect($returnPage);
        case 'update':
            $removeId = post_int('remove', 0);
            if ($removeId > 0) {
                cart_remove($removeId);
                flash('Produto removido do carrinho.', 'success');
                break;
            }
            $quantities = $_POST['qty'] ?? [];
            if (is_array($quantities)) {
                foreach ($quantities as $id => $qty) {
                    if (is_string($qty) && preg_match('/^\d{1,4}$/', $qty)) {
                        cart_set((int)$id, (int)$qty);
                    }
                }
            }
            flash('Carrinho atualizado.', 'success');
            break;
        case 'remove':
            cart_remove($productId);
            flash('Produto removido do carrinho.', 'success');
            break;
        case 'clear':
            cart_clear();
            flash('Carrinho esvaziado.', 'success');
            break;
    }
    redirect('cart.php');
}
