<?php
declare(strict_types=1);

/** @return string[] erros a mostrar no formulário (vazio se não houve submissão ou se redirecionou) */
function handle_register(): array {
    if (!is_post()) {
        return [];
    }
    verify_csrf();
    $name = post_string('name');
    $email = strtolower(post_string('email'));
    $phone = post_string('phone');
    $password = (string)($_POST['password'] ?? '');
    $confirm = (string)($_POST['password_confirm'] ?? '');
    $errors = [];

    if (mb_strlen($name) < 2 || mb_strlen($name) > 120) {
        $errors[] = 'Indica o teu nome completo (entre 2 e 120 caracteres).';
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL) || mb_strlen($email) > 190) {
        $errors[] = 'Indica um email válido.';
    }
    if ($phone !== '' && !preg_match('/^\+?[0-9 ()\-]{7,30}$/', $phone)) {
        $errors[] = 'O telefone é inválido. Usa apenas números, espaços e o sinal +.';
    }
    if (strlen($password) < 8 || strlen($password) > 72) {
        $errors[] = 'A palavra-passe deve ter entre 8 e 72 caracteres.';
    } elseif (!preg_match('/[A-Za-z]/', $password) || !preg_match('/\d/', $password)) {
        $errors[] = 'A palavra-passe deve incluir pelo menos uma letra e um número.';
    }
    if ($password !== $confirm) {
        $errors[] = 'As palavras-passe não coincidem.';
    }
    if (!$errors && user_by_email($email)) {
        $errors[] = 'Este email já está registado. Inicia sessão ou usa outro email.';
    }
    if ($errors) {
        return $errors;
    }
    try {
        create_user($name, $email, $phone, $password);
    } catch (PDOException $e) {
        if ((int)($e->errorInfo[1] ?? 0) === 1062) {
            return ['Este email já está registado. Inicia sessão ou usa outro email.'];
        }
        throw $e;
    }
    flash('Conta criada com sucesso. Já podes iniciar sessão.', 'success');
    redirect('login.php');
}

/** @return string[] */
function handle_login(): array {
    if (!is_post()) {
        return [];
    }
    verify_csrf();
    $email = strtolower(post_string('email'));
    $password = (string)($_POST['password'] ?? '');
    $ip = client_ip();

    if (login_is_blocked($email, $ip)) {
        return ['Demasiadas tentativas falhadas. Aguarda 15 minutos e tenta novamente.'];
    }
    $user = $email !== '' ? user_by_email($email) : null;
    static $dummyHash = null;
    $dummyHash ??= password_hash(bin2hex(random_bytes(8)), PASSWORD_DEFAULT);
    $hash = $user['password_hash'] ?? $dummyHash;
    $valid = password_verify($password, (string)$hash) && $user !== null;

    if (!$valid) {
        record_login_attempt($email, $ip, false);
        return ['Email ou palavra-passe incorretos.'];
    }
    record_login_attempt($email, $ip, true);
    clear_failed_logins($email, $ip);

    if (password_needs_rehash((string)$user['password_hash'], PASSWORD_DEFAULT)) {
        update_user_password_hash((int)$user['id'], password_hash($password, PASSWORD_DEFAULT));
    }
    // Novo ID de sessão após autenticação (evita fixação de sessão) e novo token CSRF.
    session_regenerate_id(true);
    unset($_SESSION['csrf']);
    $_SESSION['uid'] = (int)$user['id'];
    $next = (string)($_SESSION['after_login'] ?? '');
    unset($_SESSION['after_login']);
    current_user(true);
    if ($user['role'] === 'admin') {
        redirect('admin/dashboard.php');
    }
    redirect($next !== '' ? $next : 'index.php');
}

function handle_logout(): void {
    if (!is_post()) {
        redirect('index.php');
    }
    verify_csrf();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', [
            'expires' => time() - 42000,
            'path' => $p['path'],
            'domain' => $p['domain'],
            'secure' => $p['secure'],
            'httponly' => $p['httponly'],
            'samesite' => 'Lax',
        ]);
    }
    session_destroy();
    redirect('index.php');
}
