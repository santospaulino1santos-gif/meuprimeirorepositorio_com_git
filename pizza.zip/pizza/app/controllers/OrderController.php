<?php
declare(strict_types=1);

function checkout_default_form(array $user): array {
    return ['name' => $user['name'], 'phone' => $user['phone'], 'address' => '', 'reference' => '', 'notes' => '', 'lat' => '', 'lng' => '', 'zone' => ''];
}

/** @return array{0:array,1:string[]} [dados do formulário, erros] */
function checkout_validate_form(): array {
    $form = [
        'name' => post_string('name'),
        'phone' => post_string('phone'),
        'address' => post_string('address'),
        'reference' => post_string('reference'),
        'notes' => post_string('notes'),
        'lat' => post_string('latitude'),
        'lng' => post_string('longitude'),
        'zone' => post_string('zone'),
    ];
    $errors = [];
    if (distance_mode_manual() && !ctype_digit($form['zone'])) {
        $errors[] = 'Escolhe a zona de entrega.';
    }
    if (mb_strlen($form['name']) < 2 || mb_strlen($form['name']) > 120) {
        $errors[] = 'Indica o nome de quem recebe a encomenda.';
    }
    if (!preg_match('/^\+?[0-9 ()\-]{7,30}$/', $form['phone'])) {
        $errors[] = 'Indica um telefone válido para contacto na entrega.';
    }
    if (mb_strlen($form['address']) < 5 || mb_strlen($form['address']) > 500) {
        $errors[] = 'Indica o endereço de entrega (bairro, rua e cidade).';
    }
    if (mb_strlen($form['reference']) > 200) {
        $errors[] = 'O ponto de referência não pode ter mais de 200 caracteres.';
    }
    if (mb_strlen($form['notes']) > 300) {
        $errors[] = 'As observações não podem ter mais de 300 caracteres.';
    }
    if ($form['lat'] !== '' || $form['lng'] !== '') {
        $okLat = is_numeric($form['lat']) && (float)$form['lat'] >= -90 && (float)$form['lat'] <= 90;
        $okLng = is_numeric($form['lng']) && (float)$form['lng'] >= -180 && (float)$form['lng'] <= 180;
        if ($okLat && $okLng) {
            $form['lat'] = number_format((float)$form['lat'], 7, '.', '');
            $form['lng'] = number_format((float)$form['lng'], 7, '.', '');
        } else {
            $errors[] = 'A localização partilhada não é válida. Remove-a ou volta a partilhá-la.';
        }
    }
    return [$form, $errors];
}

/**
 * Distância (Google Routes API) + taxa (base de dados) + totais, tudo calculado no servidor.
 * @return array{ok:bool,message?:string,distance_km?:float,rate_id?:int,fee?:float,subtotal?:float,total?:float}
 */
function checkout_compute_quote(array $form, array $summary): array {
    if (distance_mode_manual()) {
        // Modo sem mapa: a zona é informada pelo cliente; a taxa vem da faixa escolhida (validada no servidor).
        $rate = null;
        foreach (delivery_rates() as $candidate) {
            if ((string)$candidate['id'] === (string)($form['zone'] ?? '')) {
                $rate = $candidate;
            }
        }
        if ($rate === null) {
            return ['ok' => false, 'message' => 'Escolhe uma zona de entrega válida.'];
        }
        $km = $rate['max_km'] !== null ? (float)$rate['max_km'] : (float)$rate['min_km'];
        $fee = round((float)$rate['fee'], 2);
        $subtotal = round((float)$summary['subtotal'], 2);
        return ['ok' => true, 'source' => 'manual', 'distance_km' => $km, 'rate_id' => (int)$rate['id'], 'fee' => $fee, 'subtotal' => $subtotal, 'total' => round($subtotal + $fee, 2)];
    }
    $lat = $form['lat'] !== '' ? (float)$form['lat'] : null;
    $lng = $form['lng'] !== '' ? (float)$form['lng'] : null;
    $route = calculate_route_distance($form['address'], $lat, $lng);
    if (!$route['ok']) {
        return ['ok' => false, 'message' => $route['message']];
    }
    $rate = delivery_rate_for_distance((float)$route['km']);
    if ($rate === null) {
        return ['ok' => false, 'message' => 'Não existe uma taxa de entrega configurada para esta distância. Contacta a pizzaria.'];
    }
    $fee = round((float)$rate['fee'], 2);
    $subtotal = round((float)$summary['subtotal'], 2);
    return [
        'ok' => true,
        'source' => 'google',
        'distance_km' => (float)$route['km'],
        'rate_id' => (int)$rate['id'],
        'fee' => $fee,
        'subtotal' => $subtotal,
        'total' => round($subtotal + $fee, 2),
    ];
}

/**
 * Processa a página de finalização: formulário → resumo com distância/taxa → confirmação.
 * @return array{step:string,summary:array,form:array,quote:?array,errors:string[],configured:bool}
 */
function handle_checkout(): array {
    $summary = cart_summary();
    if ($summary['missing']) {
        flash('Alguns produtos já não estão disponíveis e foram retirados do carrinho.', 'warning');
    }
    if (!$summary['items']) {
        if (!$summary['missing']) {
            flash('O carrinho está vazio. Escolhe pizzas no cardápio para continuar.', 'warning');
        }
        redirect('cart.php');
    }
    $user = current_user();
    $stored = $_SESSION['checkout'] ?? null;
    $form = checkout_default_form($user);
    if (is_array($stored) && isset($stored['form']) && is_array($stored['form'])) {
        $form = array_merge($form, $stored['form']);
    }
    $state = ['step' => 'form', 'summary' => $summary, 'form' => $form, 'quote' => null, 'errors' => [], 'configured' => distance_service_configured()];
    if (!is_post()) {
        return $state;
    }
    verify_csrf();
    $action = post_string('action');

    if ($action === 'quote') {
        [$posted, $errors] = checkout_validate_form();
        $state['form'] = $posted;
        if ($errors) {
            $state['errors'] = $errors;
            return $state;
        }
        $quote = checkout_compute_quote($posted, $summary);
        if (!$quote['ok']) {
            $state['errors'] = [$quote['message']];
            return $state;
        }
        $_SESSION['checkout'] = ['form' => $posted, 'quote' => $quote];
        $state['step'] = 'review';
        $state['quote'] = $quote;
        return $state;
    }

    if ($action === 'confirm') {
        if (!is_array($stored) || empty($stored['quote']) || empty($stored['form'])) {
            flash('Calcula primeiro a distância e a taxa de entrega.', 'warning');
            redirect('checkout.php');
        }
        $state['form'] = array_merge($form, $stored['form']);
        $state['step'] = 'review';
        $state['quote'] = $stored['quote'];
        // Validação no servidor: recalcula distância, taxa e totais antes de gravar.
        $fresh = checkout_compute_quote($stored['form'], $summary);
        if (!$fresh['ok']) {
            $state['errors'] = [$fresh['message']];
            return $state;
        }
        if (abs($fresh['total'] - (float)$stored['quote']['total']) > 0.009 || abs($fresh['distance_km'] - (float)$stored['quote']['distance_km']) > 0.009) {
            $_SESSION['checkout']['quote'] = $fresh;
            $state['quote'] = $fresh;
            $state['errors'] = ['Os valores foram atualizados desde o último cálculo. Confirma o novo total para finalizar.'];
            return $state;
        }
        try {
            $orderId = create_order((int)$user['id'], $stored['form'], $fresh, cart_raw());
        } catch (RuntimeException $e) {
            flash($e->getMessage(), 'error');
            redirect('cart.php');
        }
        cart_clear();
        unset($_SESSION['checkout']);
        flash('Encomenda #' . $orderId . ' confirmada. O pagamento é feito em dinheiro no momento da entrega.', 'success');
        redirect('order.php?id=' . $orderId);
    }

    // action === 'edit' (ou desconhecida): volta ao formulário com os dados guardados.
    return $state;
}
