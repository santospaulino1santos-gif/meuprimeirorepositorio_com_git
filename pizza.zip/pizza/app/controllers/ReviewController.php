<?php
declare(strict_types=1);

/**
 * Submissão da avaliação de uma encomenda entregue.
 * @param array $order encomenda já verificada como pertencente ao utilizador autenticado
 * @param array $items itens da encomenda
 * @return string[] erros (vazio se não houve submissão; redireciona em caso de sucesso)
 */
function handle_review_submit(array $order, array $items): array {
    if (!is_post() || post_string('action') !== 'review') {
        return [];
    }
    verify_csrf();
    $errors = [];
    if ($order['status'] !== 'delivered') {
        return ['Só podes avaliar uma encomenda depois de ela ser marcada como entregue.'];
    }
    $rating = post_int('rating', 0);
    if ($rating < 1 || $rating > 5) {
        $errors[] = 'Escolhe uma classificação de 1 a 5 estrelas.';
    }
    $comment = post_string('comment');
    if (mb_strlen($comment) > 1000) {
        $errors[] = 'O comentário não pode ter mais de 1000 caracteres.';
    }
    $validIds = array_map(static fn(array $item): int => (int)$item['id'], $items);
    $itemId = count($items) === 1 ? (int)$items[0]['id'] : post_int('order_item_id', 0);
    if (!in_array($itemId, $validIds, true)) {
        $errors[] = 'Escolhe a pizza que queres avaliar.';
    }
    if ($errors) {
        return $errors;
    }
    try {
        $photo = store_private_image('photo', 'review_photos');
    } catch (RuntimeException $e) {
        return [$e->getMessage()];
    }
    try {
        create_review((int)$order['user_id'], (int)$order['id'], $itemId, $rating, $comment, $photo);
    } catch (Throwable $e) {
        if ($photo !== null) {
            delete_private_file('review_photos', $photo['file']);
        }
        if ($e instanceof RuntimeException) {
            return [$e->getMessage()];
        }
        throw $e;
    }
    flash('Obrigado pela tua avaliação!', 'success');
    redirect('order.php?id=' . (int)$order['id']);
}
