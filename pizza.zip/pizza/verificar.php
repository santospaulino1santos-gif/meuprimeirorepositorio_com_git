<?php
/** Diagnóstico local do PizzaHub para XAMPP. Não apresenta credenciais. */
require_once __DIR__ . '/app/config/config.php';
$checks = [];
$checks[] = ['PHP 8.1 ou superior', version_compare(PHP_VERSION, '8.1.0', '>='), PHP_VERSION];
$checks[] = ['Extensão PDO', extension_loaded('pdo'), extension_loaded('pdo') ? 'Ativa' : 'Não está ativa'];
$checks[] = ['Driver PDO MySQL', extension_loaded('pdo_mysql'), extension_loaded('pdo_mysql') ? 'Ativo' : 'Ativa pdo_mysql no php.ini do XAMPP'];
$checks[] = ['Extensão fileinfo', extension_loaded('fileinfo'), extension_loaded('fileinfo') ? 'Ativa' : 'Não está ativa'];
$checks[] = ['Extensão mbstring', extension_loaded('mbstring'), extension_loaded('mbstring') ? 'Ativa' : 'Ativa mbstring no php.ini do XAMPP'];
$checks[] = ['Pasta storage gravável', is_writable(STORAGE_PATH), is_writable(STORAGE_PATH) ? 'OK' : 'Verifica permissões da pasta storage'];
$checks[] = ['Pasta uploads gravável', is_writable(ROOT_PATH . '/uploads'), is_writable(ROOT_PATH . '/uploads') ? 'OK' : 'Verifica permissões da pasta uploads'];
$dbMessage = 'Não testada';
$dbOk = false;
$tablesOk = false;
if (extension_loaded('pdo_mysql')) {
    try {
        require_once __DIR__ . '/app/config/database.php';
        $pdo = db();
        $dbOk = true;
        $dbMessage = 'Ligação MySQL estabelecida';
        $required = ['users','products','promotions','delivery_rates','orders','order_items','reviews'];
        $found = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
        $missing = array_values(array_diff($required, $found));
        $tablesOk = count($missing) === 0;
        $dbMessage .= $tablesOk ? '; tabelas principais encontradas' : '; faltam: ' . implode(', ', $missing);
    } catch (Throwable $e) {
        $dbMessage = $e->getMessage();
    }
}
$checks[] = ['Ligação à base de dados', $dbOk, $dbMessage];
$checks[] = ['Tabelas da aplicação', $tablesOk, $tablesOk ? 'Estrutura principal encontrada' : 'Importa database/schema.sql no phpMyAdmin'];
?><!doctype html>
<html lang="pt"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Diagnóstico PizzaHub</title>
<style>body{font:16px Arial,sans-serif;background:#f5f5f5;color:#222;margin:0;padding:24px}.wrap{max-width:850px;margin:auto;background:white;padding:24px;border-radius:12px}h1{margin-top:0}.item{padding:13px 0;border-bottom:1px solid #ddd}.ok{color:#137333;font-weight:bold}.bad{color:#b3261e;font-weight:bold}.hint{color:#555;font-size:14px}a{color:#b3261e}</style></head><body><main class="wrap"><h1>Diagnóstico do PizzaHub</h1><p>Esta página verifica os requisitos básicos do XAMPP sem mostrar palavras-passe.</p>
<?php foreach ($checks as [$label,$ok,$detail]): ?><div class="item"><strong><?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?></strong> — <span class="<?= $ok ? 'ok' : 'bad' ?>"><?= $ok ? 'OK' : 'ATENÇÃO' ?></span><div class="hint"><?= htmlspecialchars($detail, ENT_QUOTES, 'UTF-8') ?></div></div><?php endforeach; ?>
<p>Depois de corrigires os itens, volta a abrir <a href="index.php">a página inicial</a>.</p><p class="hint">Por segurança, apaga ou renomeia verificar.php depois de terminares o diagnóstico.</p></main></body></html>
