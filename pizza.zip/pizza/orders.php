<?php
require_once __DIR__ . '/app/config/bootstrap.php';
require_login();
$orders = orders_for_user((int)current_user()['id']);
require __DIR__ . '/app/views/pages/orders.php';
