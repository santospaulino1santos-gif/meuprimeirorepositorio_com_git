<?php
require_once __DIR__ . '/app/config/bootstrap.php';
if (current_user()) {
    redirect('index.php');
}
$errors = handle_register();
require __DIR__ . '/app/views/pages/register.php';
