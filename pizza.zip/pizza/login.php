<?php
require_once __DIR__ . '/app/config/bootstrap.php';
if (current_user()) {
    redirect(is_admin() ? 'admin/dashboard.php' : 'index.php');
}
$errors = handle_login();
require __DIR__ . '/app/views/pages/login.php';
