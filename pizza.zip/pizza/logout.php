<?php
require_once __DIR__ . '/app/config/bootstrap.php';
handle_logout();
