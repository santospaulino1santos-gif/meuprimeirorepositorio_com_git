PIZZAHUB V3 — INSTALAÇÃO LIMPA NO XAMPP (WINDOWS)

IMPORTANTE:
Esta V3 usa uma base de dados NOVA chamada pizzahub_v3.
A tua base antiga chamada pizzaria não será apagada nem alterada.
Não importes migrate_v2.sql. Para esta instalação nova, usa apenas schema.sql.

1. Faz uma cópia da pasta antiga C:\\xampp\\htdocs\\pizza, se quiseres preservá-la.
2. Extrai a pasta "pizza" deste ZIP para C:\\xampp\\htdocs\\pizza.
3. Abre o XAMPP Control Panel e inicia Apache e MySQL.
4. Abre http://localhost/phpmyadmin
5. Clica em Importar e seleciona:
   C:\\xampp\\htdocs\\pizza\\database\\schema.sql
   O ficheiro cria a base pizzahub_v3 e todas as tabelas necessárias.
6. Opcional: para inserir 3 pizzas de demonstração, importa também:
   C:\\xampp\\htdocs\\pizza\\database\\seed_demo.sql
   (Faz isso depois de importar schema.sql.)
7. Abre http://localhost/pizza/verificar.php
8. Se os testes estiverem OK, abre http://localhost/pizza/

CONFIGURAÇÃO XAMPP INCLUÍDA
- Host: 127.0.0.1
- Base de dados: pizzahub_v3
- Utilizador: root
- Palavra-passe: vazia (padrão XAMPP)
- Entrega em modo manual: não precisa de chave Google Maps.
- A taxa de entrega vem das zonas configuradas na tabela delivery_rates.

CRIAR ADMINISTRADOR
Abre o Prompt de Comando e executa:
C:\\xampp\\php\\php.exe C:\\xampp\\htdocs\\pizza\\bin\\criar_admin.php
Segue as instruções para criar o utilizador administrador.

SE O DIAGNÓSTICO INDICAR QUE PDO MYSQL NÃO ESTÁ ATIVO
1. No XAMPP Control Panel, junto ao Apache, clica Config > PHP (php.ini).
2. Procura extension=pdo_mysql e confirma que não está comentada com ponto e vírgula.
3. Guarda e reinicia o Apache.

REQUISITOS
- PHP 8.1 ou superior
- MySQL/MariaDB
- Extensões PDO MySQL e fileinfo
- A extensão mbstring é recomendada/necessária para validação de texto.

Se aparecer algum erro, guarda a mensagem completa e o ficheiro/linha indicados.
Não apagues a base antiga pizzaria: a V3 não precisa dela.

Para importar o esquema numa base InfinityFree nova e vazia, abre o phpMyAdmin, seleciona a base de dados atribuída pelo InfinityFree e importa `database/schema.sql`. O SQL foi ajustado para não tentar criar nem selecionar `pizzahub_v3` por conta própria. **Não importes este esquema sobre tabelas existentes sem backup e verificação**, pois `IF NOT EXISTS` não altera estruturas antigas.
