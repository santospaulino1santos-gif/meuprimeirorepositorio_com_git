<?php
require_once __DIR__ . '/../app/config/bootstrap.php';
require_admin();
handle_admin_order_status();
$orderId = get_int('id');
if ($orderId > 0) {
    $order = order_by_id($orderId);
    if (!$order) {
        abort(404, 'Encomenda não encontrada.');
    }
    $items = order_items($orderId);
    $review = review_for_order($orderId);
    require __DIR__ . '/../app/views/admin/order_detail.php';
    return;
}
$status = get_string('status');
$search = get_string('q');
$page = page_number();
$perPage = 20;
$total = admin_orders_count($status, $search);
$orders = admin_orders($status, $search, $perPage, ($page - 1) * $perPage);
$counts = admin_order_counts_by_status();
require __DIR__ . '/../app/views/admin/orders.php';
