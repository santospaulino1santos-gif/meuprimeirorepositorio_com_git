<?php
require_once __DIR__ . '/../app/config/bootstrap.php';
require_admin();
$stats = dashboard_stats();
$series = daily_orders_series(7);
$top = top_products(5);
$recent = recent_orders(5);
$configured = distance_service_configured();
require __DIR__ . '/../app/views/admin/dashboard.php';
