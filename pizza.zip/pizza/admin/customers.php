<?php
require_once __DIR__ . '/../app/config/bootstrap.php';
require_admin();
$customerId = get_int('id');
if ($customerId > 0) {
    $customer = customer_by_id($customerId);
    if (!$customer) {
        abort(404, 'Cliente não encontrado.');
    }
    $orders = orders_for_user($customerId);
    require __DIR__ . '/../app/views/admin/customer_detail.php';
    return;
}
$search = get_string('q');
$page = page_number();
$perPage = 20;
$total = customers_count($search);
$customers = customers_list($search, $perPage, ($page - 1) * $perPage);
require __DIR__ . '/../app/views/admin/customers.php';
