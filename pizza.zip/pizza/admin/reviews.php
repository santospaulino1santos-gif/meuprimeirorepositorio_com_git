<?php
require_once __DIR__ . '/../app/config/bootstrap.php';
require_admin();
$rating = get_int('rating');
$page = page_number();
$perPage = 12;
$total = admin_reviews_count($rating);
$reviews = admin_reviews($rating, $perPage, ($page - 1) * $perPage);
$summary = reviews_summary();
require __DIR__ . '/../app/views/admin/reviews.php';
