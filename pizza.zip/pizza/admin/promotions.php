<?php
require_once __DIR__ . '/../app/config/bootstrap.php';
require_admin();
$result = handle_admin_promotions();
$editId = get_int('edit');
$editing = $editId > 0 ? promotion_by_id($editId) : null;
if ($editId > 0 && !$editing) {
    abort(404, 'Promoção não encontrada.');
}
$promotions = all_promotions();
$selectableProducts = admin_products('all');
$selectableProducts = array_values(array_filter($selectableProducts, static fn(array $p): bool => $p['deleted_at'] === null));
require __DIR__ . '/../app/views/admin/promotions.php';
