<?php
require_once __DIR__ . '/../app/config/bootstrap.php';
require_admin();
$result = handle_admin_products();
$filter = admin_product_filter();
$counts = admin_product_counts();
$editId = get_int('edit');
$viewId = get_int('view');
$editing = $editId > 0 ? product_admin_by_id($editId) : null;
$viewing = $viewId > 0 ? product_admin_by_id($viewId) : null;
if (($editId > 0 && !$editing) || ($viewId > 0 && !$viewing)) {
    abort(404, 'Produto não encontrado.');
}
$products = admin_products($filter);
require __DIR__ . '/../app/views/admin/products.php';
