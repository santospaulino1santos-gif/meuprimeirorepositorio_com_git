<?php
require_once __DIR__ . '/../app/config/bootstrap.php';
require_admin();
$errors = handle_admin_delivery();
$rates = delivery_rates_labeled();
require __DIR__ . '/../app/views/admin/delivery.php';
