<?php
require_once __DIR__ . '/app/config/bootstrap.php';
$products = catalog_products();
require __DIR__ . '/app/views/pages/menu.php';
