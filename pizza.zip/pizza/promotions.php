<?php
require_once __DIR__ . '/app/config/bootstrap.php';
$promotions = active_promotions();
require __DIR__ . '/app/views/pages/promotions.php';
