<?php
require_once __DIR__ . '/app/config/bootstrap.php';
require_login();
$user = current_user();
// A encomenda só é carregada se pertencer ao utilizador autenticado.
$order = order_for_user(get_int('id'), (int)$user['id']);
if (!$order) {
    abort(404, 'Encomenda não encontrada.');
}
$items = order_items((int)$order['id']);
$errors = handle_review_submit($order, $items);
$review = review_for_order((int)$order['id']);
require __DIR__ . '/app/views/pages/order.php';
