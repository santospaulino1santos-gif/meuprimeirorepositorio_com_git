<?php
require_once __DIR__ . '/app/config/bootstrap.php';
require_login();

// Fotografias de avaliações: guardadas fora da pasta pública e servidas só ao dono da avaliação ou ao administrador.
$reviewId = get_int('review');
$photo = $reviewId > 0 ? review_photo_by_review($reviewId) : null;
$user = current_user();
if (!$photo || !($user['role'] === 'admin' || (int)$photo['user_id'] === (int)$user['id'])) {
    abort(404, 'Imagem não encontrada.');
}
$path = private_file_path('review_photos', (string)$photo['file_name']);
$mime = (string)$photo['mime_type'];
if ($path === null || !isset(allowed_image_types()[$mime])) {
    abort(404, 'Imagem não encontrada.');
}
session_write_close();
header('Content-Type: ' . $mime);
header('Content-Length: ' . (string)filesize($path));
header('Content-Disposition: inline; filename="avaliacao-' . $reviewId . '"');
header('Cache-Control: private, max-age=86400');
header("Content-Security-Policy: default-src 'none'; sandbox");
readfile($path);
exit;
