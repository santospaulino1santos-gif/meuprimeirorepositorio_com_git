# Testes

## Executados (estáticos, neste ambiente)
| Verificação | Resultado |
|---|---|
| Equilíbrio de `() [] {}` em todos os `.php` (strings/comentários ignorados) | sem problemas |
| Pares `if/foreach/for/while` com sintaxe alternativa vs `end…;` nas vistas | sem problemas |
| Funções chamadas vs definidas no projeto | nenhuma função do projeto por definir |
| Sintaxe de `assets/js/site.js` e `admin.js` (`node --check`) | sem erros |
| Caminhos `require` a partir da raiz e de `admin/` | conferidos |
| SQL de migração gerado e relido | conferido por leitura (não executado) |

## NÃO executados (exigem XAMPP, MySQL e chave Google)
Nenhum fluxo foi testado em execução: registo, login, permissões, catálogo, carrinho, checkout, cálculo de taxa, estados, histórico, avaliação, upload, gestão de produtos/promoções/clientes/taxas, aspeto visual e responsividade, e `http://localhost/pizza/`.

## Lista de testes manuais
1. Abrir `http://localhost/pizza/`: CSS, logótipo e menu carregam; consola do navegador sem erros (jQuery carregado).
2. Registar cliente (palavra-passe fraca deve falhar); login; logout.
3. Cliente a abrir `admin/dashboard.php` deve receber 403; sem sessão, ir para o login.
4. Admin: criar produto com fotografia e categoria; ver em `menu.php`; filtrar por categoria; ocultar, reativar, remover (o produto some e as encomendas antigas mantêm o nome).
5. Admin: criar promoção com produto e preço; ver preço reduzido no cardápio e no carrinho; desativar; testar datas inválidas.
6. Cliente: adicionar ao carrinho (contador atualiza sem recarregar), alterar quantidades, remover.
7. Checkout sem chave Google: mensagem de configuração e botão desativado. Com chave: distância, taxa (80/160/320 conforme faixa), total; confirmar; ver histórico.
8. Admin: alterar taxas; nova encomenda usa o novo valor, a antiga mantém o anterior.
9. Admin: mudar estado até Entregue; transições inválidas devem ser recusadas.
10. Cliente: avaliar a encomenda entregue (estrelas, comentário, JPG/PNG/WEBP; testar ficheiro .php renomeado e ficheiro >5 MB); segunda avaliação deve ser recusada; admin vê a fotografia em `admin/reviews.php`; outro cliente não abre `media.php?review=ID`.
11. Cliente A a abrir `order.php?id=` de B recebe 404.
12. 6 logins falhados seguidos bloqueiam temporariamente.
13. Telemóvel (largura ~375 px): menu, cardápio, tabelas em formato de cartões, painel com menu lateral recolhível.
