<?php
require_once __DIR__ . '/app/config/bootstrap.php';
require_login();
$state = handle_checkout();
require __DIR__ . '/app/views/pages/checkout.php';
