<?php
require_once __DIR__ . '/app/config/bootstrap.php';
$featured = featured_products(4);
$promotions = array_slice(active_promotions(), 0, 3);
$rates = delivery_rates_labeled();
require __DIR__ . '/app/views/pages/home.php';
