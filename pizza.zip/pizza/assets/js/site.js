/* PizzaHub — interações da área do cliente (jQuery) */
$(function () {
  'use strict';

  // Menu em ecrãs pequenos
  $('.nav-toggle').on('click', function () {
    var open = $('#main-nav').toggleClass('is-open').hasClass('is-open');
    $(this).attr('aria-expanded', open);
  });

  // Mensagens de sucesso desaparecem sozinhas
  $('.alert.success').delay(6000).fadeOut(400);

  // Botões + e - das quantidades
  $(document).on('click', '.qty-btn', function () {
    var $input = $(this).siblings('input[type="number"]');
    var step = parseInt($(this).data('step'), 10) || 0;
    var min = parseInt($input.attr('min'), 10) || 0;
    var max = parseInt($input.attr('max'), 10) || 30;
    var value = (parseInt($input.val(), 10) || 0) + step;
    $input.val(Math.max(min, Math.min(max, value)));
  });

  // Filtro por categoria no cardápio (sem recarregar a página)
  $('.filter-btn').on('click', function () {
    var filter = $(this).data('filter');
    $('.filter-btn').removeClass('is-active');
    $(this).addClass('is-active');
    var visible = 0;
    $('#product-grid .product-card').each(function () {
      var show = filter === 'all' || $(this).data('category') === filter;
      $(this).toggle(show);
      if (show) { visible++; }
    });
    $('#filter-empty').prop('hidden', visible > 0);
  });

  // Mensagem curta no canto do ecrã
  function toast(text, isError) {
    $('.toast').remove();
    var $t = $('<div class="toast" role="status"></div>').text(text).toggleClass('is-error', !!isError);
    $('body').append($t);
    setTimeout(function () { $t.fadeOut(300, function () { $t.remove(); }); }, 3500);
  }

  // Adicionar ao carrinho sem recarregar; atualiza o contador do cabeçalho.
  // Se falhar, o formulário é enviado normalmente.
  $('.add-form').on('submit', function (event) {
    var $form = $(this);
    event.preventDefault();
    var $button = $form.find('button[type="submit"]').prop('disabled', true);
    $.ajax({ url: $form.attr('action'), method: 'POST', data: $form.serialize(), dataType: 'html' })
      .done(function (html) {
        var $page = $('<div>').append($.parseHTML(html));
        var count = $page.find('#cart-count').first().text();
        if (count !== '') { $('#cart-count').text(count); }
        var $alert = $page.find('.alert').first();
        toast($alert.length ? $alert.text() : 'Adicionado ao carrinho.', $alert.hasClass('error'));
        $button.prop('disabled', false);
      })
      .fail(function () {
        $form.off('submit').trigger('submit');
      });
  });

  // Confirmação antes de ações destrutivas
  $(document).on('submit', 'form[data-confirm]', function (event) {
    if (!window.confirm($(this).data('confirm'))) { event.preventDefault(); }
  });

  // Evita envio duplo (confirmar encomenda)
  $('form[data-once]').on('submit', function () {
    $(this).find('button[type="submit"]').prop('disabled', true).text('A processar...');
  });

  // Localização do cliente (usada no cálculo da distância)
  var $lat = $('#latitude'), $lng = $('#longitude'), $status = $('#location-status');
  $('#use-location').on('click', function () {
    if (!navigator.geolocation) {
      $status.text('O teu navegador não suporta GPS. Escreve a morada completa e contacta a pizzaria para combinar a entrega.');
      return;
    }
    $status.text('A obter a localização...');
    navigator.geolocation.getCurrentPosition(function (pos) {
      $lat.val(pos.coords.latitude.toFixed(7));
      $lng.val(pos.coords.longitude.toFixed(7));
      $status.text('Localização GPS marcada! Confirma o ponto no Google Maps.');
      $('#clear-location').prop('hidden', false);
      $('#location-map-link').attr('href', 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(pos.coords.latitude + ',' + pos.coords.longitude)).prop('hidden', false);
    }, function () {
      $status.text('Não foi possível obter o GPS. Verifica a permissão de localização e usa HTTPS ou localhost.');
    }, { enableHighAccuracy: true, timeout: 15000 });
  });
  $('#clear-location').on('click', function () {
    $lat.val(''); $lng.val('');
    $status.text('Localização removida. Partilha o GPS novamente antes de finalizar.');
    $('#location-map-link').prop('hidden', true).attr('href', '#');
    $(this).prop('hidden', true);
  });

  // Pré-visualização e verificação da imagem antes de enviar
  $('input[type="file"][data-preview]').on('change', function () {
    var file = this.files && this.files[0];
    var $preview = $($(this).data('preview'));
    var max = parseInt($(this).data('max-bytes'), 10) || 0;
    if (!file) { $preview.prop('hidden', true); return; }
    if (!/^image\/(jpeg|png|webp)$/.test(file.type) || (max && file.size > max)) {
      toast('Imagem inválida: usa JPG, PNG ou WEBP dentro do tamanho máximo.', true);
      $(this).val('');
      $preview.prop('hidden', true);
      return;
    }
    $preview.attr('src', URL.createObjectURL(file)).prop('hidden', false);
  });
});
