/* PizzaHub — interações do painel administrativo (jQuery) */
$(function () {
  'use strict';

  $('.nav-toggle').on('click', function () {
    var open = $('#sidebar').toggleClass('is-open').hasClass('is-open');
    $(this).attr('aria-expanded', open);
  });

  $('.alert.success').delay(6000).fadeOut(400);

  // Confirmação antes de remover
  $(document).on('submit', 'form[data-confirm]', function (event) {
    if (!window.confirm($(this).data('confirm'))) { event.preventDefault(); }
  });

  // Filtros que se aplicam ao mudar o valor
  $('[data-autosubmit]').on('change', function () { $(this).closest('form').trigger('submit'); });

  // Pré-visualização da imagem escolhida
  $('input[type="file"][data-preview]').on('change', function () {
    var file = this.files && this.files[0];
    var $preview = $($(this).data('preview'));
    var max = parseInt($(this).data('max-bytes'), 10) || 0;
    if (!file) { $preview.prop('hidden', true); return; }
    if (!/^image\/(jpeg|png|webp)$/.test(file.type) || (max && file.size > max)) {
      window.alert('Imagem inválida: usa JPG, PNG ou WEBP dentro do tamanho máximo.');
      $(this).val('');
      $preview.prop('hidden', true);
      return;
    }
    $preview.attr('src', URL.createObjectURL(file)).prop('hidden', false);
  });

  // Evita duplo clique ao guardar
  $('form').on('submit', function () {
    if (!this.hasAttribute('data-confirm')) {
      var $b = $(this).find('button[type="submit"]').first();
      setTimeout(function () { $b.prop('disabled', true); }, 0);
    }
  });
});
