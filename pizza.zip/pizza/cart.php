<?php
require_once __DIR__ . '/app/config/bootstrap.php';
handle_cart_post();
$cart = cart_summary();
$cartItems = $cart['items'];
$subtotal = $cart['subtotal'];
if ($cart['missing']) {
    flash('Alguns produtos já não estão disponíveis e foram retirados do carrinho.', 'warning');
}
require __DIR__ . '/app/views/pages/cart.php';
