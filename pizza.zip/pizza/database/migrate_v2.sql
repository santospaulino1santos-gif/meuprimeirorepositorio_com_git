-- PizzaHub — migração da base de dados da versão anterior para a versão final V2.
-- Seguro para repetir: só adiciona o que falta e NÃO apaga tabelas nem dados.
-- Faz uma cópia de segurança (phpMyAdmin > Exportar) antes de importar.
-- Importa com a base de dados "pizzaria" selecionada.

-- users.phone
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='users' AND COLUMN_NAME='phone'), 'ALTER TABLE users ADD COLUMN phone VARCHAR(30) NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- products.category
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='products' AND COLUMN_NAME='category'), 'ALTER TABLE products ADD COLUMN category VARCHAR(20) NOT NULL DEFAULT ''tradicionais''', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- products.deleted_at
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='products' AND COLUMN_NAME='deleted_at'), 'ALTER TABLE products ADD COLUMN deleted_at DATETIME NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- products.updated_at
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='products' AND COLUMN_NAME='updated_at'), 'ALTER TABLE products ADD COLUMN updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- índice idx_products_visibility
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='products' AND INDEX_NAME='idx_products_visibility'), 'ALTER TABLE products ADD INDEX idx_products_visibility (active, deleted_at)', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- índice idx_products_category
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='products' AND INDEX_NAME='idx_products_category'), 'ALTER TABLE products ADD INDEX idx_products_category (category)', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- promotions.conditions
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='promotions' AND COLUMN_NAME='conditions'), 'ALTER TABLE promotions ADD COLUMN conditions TEXT NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- promotions.product_id
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='promotions' AND COLUMN_NAME='product_id'), 'ALTER TABLE promotions ADD COLUMN product_id INT NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- promotions.promo_price
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='promotions' AND COLUMN_NAME='promo_price'), 'ALTER TABLE promotions ADD COLUMN promo_price DECIMAL(10,2) NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- promotions.starts_at
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='promotions' AND COLUMN_NAME='starts_at'), 'ALTER TABLE promotions ADD COLUMN starts_at DATETIME NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- promotions.ends_at
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='promotions' AND COLUMN_NAME='ends_at'), 'ALTER TABLE promotions ADD COLUMN ends_at DATETIME NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- promotions.updated_at
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='promotions' AND COLUMN_NAME='updated_at'), 'ALTER TABLE promotions ADD COLUMN updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- chave estrangeira fk_promotions_product
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='promotions' AND CONSTRAINT_NAME='fk_promotions_product'), 'ALTER TABLE promotions ADD CONSTRAINT fk_promotions_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- orders.customer_name
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='customer_name'), 'ALTER TABLE orders ADD COLUMN customer_name VARCHAR(120) NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- orders.phone
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='phone'), 'ALTER TABLE orders ADD COLUMN phone VARCHAR(30) NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- orders.address_reference
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='address_reference'), 'ALTER TABLE orders ADD COLUMN address_reference VARCHAR(200) NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- orders.latitude
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='latitude'), 'ALTER TABLE orders ADD COLUMN latitude DECIMAL(10,7) NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- orders.longitude
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='longitude'), 'ALTER TABLE orders ADD COLUMN longitude DECIMAL(10,7) NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- orders.notes
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='notes'), 'ALTER TABLE orders ADD COLUMN notes VARCHAR(300) NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- orders.distance_km
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='distance_km'), 'ALTER TABLE orders ADD COLUMN distance_km DECIMAL(8,2) NOT NULL DEFAULT 0', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- orders.delivery_rate_id
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='delivery_rate_id'), 'ALTER TABLE orders ADD COLUMN delivery_rate_id INT NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- orders.payment_method
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='payment_method'), 'ALTER TABLE orders ADD COLUMN payment_method VARCHAR(30) NOT NULL DEFAULT ''cash_on_delivery''', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- orders.delivered_at
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='delivered_at'), 'ALTER TABLE orders ADD COLUMN delivered_at DATETIME NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- orders.updated_at
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='updated_at'), 'ALTER TABLE orders ADD COLUMN updated_at TIMESTAMP NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- índice idx_orders_status
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND INDEX_NAME='idx_orders_status'), 'ALTER TABLE orders ADD INDEX idx_orders_status (status)', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- índice idx_orders_created
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND INDEX_NAME='idx_orders_created'), 'ALTER TABLE orders ADD INDEX idx_orders_created (created_at)', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- chave estrangeira fk_orders_rate
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND CONSTRAINT_NAME='fk_orders_rate'), 'ALTER TABLE orders ADD CONSTRAINT fk_orders_rate FOREIGN KEY (delivery_rate_id) REFERENCES delivery_rates(id) ON DELETE SET NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- order_items.list_price
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='order_items' AND COLUMN_NAME='list_price'), 'ALTER TABLE order_items ADD COLUMN list_price DECIMAL(10,2) NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- order_items.promotion_id
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='order_items' AND COLUMN_NAME='promotion_id'), 'ALTER TABLE order_items ADD COLUMN promotion_id INT NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- chave estrangeira fk_items_promotion
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='order_items' AND CONSTRAINT_NAME='fk_items_promotion'), 'ALTER TABLE order_items ADD CONSTRAINT fk_items_promotion FOREIGN KEY (promotion_id) REFERENCES promotions(id) ON DELETE SET NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- reviews.product_id
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='reviews' AND COLUMN_NAME='product_id'), 'ALTER TABLE reviews ADD COLUMN product_id INT NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- reviews.product_name
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='reviews' AND COLUMN_NAME='product_name'), 'ALTER TABLE reviews ADD COLUMN product_name VARCHAR(120) NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- chave estrangeira fk_reviews_product
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='reviews' AND CONSTRAINT_NAME='fk_reviews_product'), 'ALTER TABLE reviews ADD CONSTRAINT fk_reviews_product FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- índice uq_reviews_order
SET @ddl = (SELECT IF(((SELECT COUNT(*)=0 FROM information_schema.STATISTICS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='reviews' AND INDEX_NAME='uq_reviews_order') AND (SELECT COUNT(*)=0 FROM (SELECT order_id FROM reviews GROUP BY order_id HAVING COUNT(*)>1) d)), 'ALTER TABLE reviews ADD UNIQUE INDEX uq_reviews_order (order_id)', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Novas tabelas
CREATE TABLE IF NOT EXISTS review_photos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  review_id INT NOT NULL,
  file_name VARCHAR(100) NOT NULL,
  mime_type VARCHAR(40) NOT NULL,
  size_bytes INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_photos_review (review_id),
  CONSTRAINT fk_photos_review FOREIGN KEY (review_id) REFERENCES reviews(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS login_attempts (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(190) NOT NULL,
  ip VARCHAR(45) NOT NULL,
  success TINYINT(1) NOT NULL DEFAULT 0,
  attempted_at DATETIME NOT NULL,
  INDEX idx_attempts_email (email, ip, attempted_at),
  INDEX idx_attempts_ip (ip, attempted_at)
) ENGINE=InnoDB;

-- Taxas iniciais (só se a tabela estiver vazia). As taxas existentes são mantidas.
INSERT INTO delivery_rates (min_km, max_km, fee)
SELECT t.a, t.b, t.c FROM (
  SELECT 0 AS a, 5 AS b, 80 AS c
  UNION ALL SELECT 5, 10, 160
  UNION ALL SELECT 10, NULL, 320
) t WHERE NOT EXISTS (SELECT 1 FROM delivery_rates);

-- Fotografias de avaliações antigas (coluna image_path) ficam preservadas na própria coluna.

-- orders.distance_source (google = calculada pela API; manual = zona informada pelo cliente)
SET @ddl = (SELECT IF((SELECT COUNT(*)=0 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='orders' AND COLUMN_NAME='distance_source'), 'ALTER TABLE orders ADD COLUMN distance_source VARCHAR(10) NOT NULL DEFAULT ''google''', 'SELECT 1'));
PREPARE stmt FROM @ddl; EXECUTE stmt; DEALLOCATE PREPARE stmt;
