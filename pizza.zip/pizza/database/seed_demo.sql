-- OPCIONAL, apenas para demonstração local: cria 3 pizzas de exemplo SEM fotografia.
-- Depois adiciona as fotografias reais em Administração > Produtos > Editar.
-- Não cria encomendas, clientes nem avaliações.
USE pizzahub_v3;
INSERT INTO products (name, description, category, price) VALUES
('Margherita', 'Molho de tomate, mussarela e manjericão.', 'tradicionais', 350),
('Pepperoni', 'Molho de tomate, mussarela e pepperoni.', 'tradicionais', 400),
('Vegetariana', 'Tomate, queijo e legumes frescos.', 'especiais', 400);
